import os
import numpy as np
from itertools import product

import bishop
import bishop.base_optics as bop
import bishop.utilities as utils
import bishop.settings as sett


ALL_CONFS = [ 'xxx', 'xxy', 'xxz', 'xyy', 'xzz',
              'yxx', 'yxy', 'yyy', 'yyz', 'yzz',
              'zxx', 'zxz', 'zyy', 'zyz', 'zzz' ]
  
ALL_CONFS_PERM = [ 'xxx', 'xxy', 'xxz', 'xyx', 'xyy', 'xzx', 'xzz',
                   'yxx', 'yxy', 'yyx', 'yyy', 'yyz', 'yzy', 'yzz',
                   'zxx', 'zxz', 'zyy', 'zyz', 'zzx', 'zzy', 'zzz' ]


def check_dict_integrities(optimization, crystal, save):
    
    utils.check_dict_integrity(optimization, 'optimization', set(), 
                               {'crystal_length', 'pump_FWHM', 'test_values',
                                'parameter', 'criteria', 'npoints'})
    
    utils.check_dict_integrity(crystal, 'crystal',
                               {'material', 'temperature'},
                               {'configuration', 'forbid_perms'})
    
    utils.check_dict_integrity(save, 'save', {'folder_name'}, 
                               {'compute', 'sweep_plots', 'final_plots',
                                'final_plots_lines', 'prefix', 'optlog'})
    
    
    
def parse_args(*args, input_mode='wavelength'):
    
    """
    Parser for the pump, signal and idler data, returning both the angular 
    frequencies (rad/s) and the wavelengths (um).

    Parameters
    ----------
    args : floats
        The user can input three combinations of values (ie wavelengths or an-
        gular frequencies) and value intervals (pump width). If 2 or 3 
        arguments are provided, they must be 2 or 3 values, respectively. If 4
        arguments are provided, they must be given in the order val1, valInt1, 
        val2, val3, where valInt1 is to be understood as a value interval
        around a central value of val1. 
    
    input_mode : string
        Valid input_modes are 'wavelength' and 'angfreq', meaning the units of
        measurement of all values given in the args.
    
    Returns
    -------
        Two lists containing, respectively, all values given in args (in the 
        same order), in rad/s and in um.
    
    """
    
    Nargs = len(args)

    if Nargs == 2:
        # 2 arguments mean signal, idler

        if input_mode == 'wavelength':
            ws, wi = bop.wl2w(args)
            wls, wli = args
        elif input_mode == 'angfreq':
            wls, wli = bop.w2wl(args)
            ws, wi = args

        return [ws, wi], [wls, wli]

    elif Nargs == 3:
        # 3 arguments mean pump, signal, idler
        
        if input_mode == 'wavelength':
            wp, ws, wi = bop.wl2w(args)
            wlp, wls, wli = args
        elif input_mode == 'angfreq':
            wlp, wls, wli = bop.w2wl(args)
            wp, ws, wi = args

        return [wp, ws, wi], [wlp, wls, wli]

    elif Nargs == 4:
        # 4 arguments mean pump, sigma_pump, signal, idler
        pump, sigma_pump, signal, idler = args

        if input_mode == 'wavelength':
            wp, ws, wi = bop.wl2w([pump, signal, idler])
            wlp, wls, wli = pump, signal, idler
            spw = bop.wl2w_std(wlp, sigma_pump)
            spwl = sigma_pump
        elif input_mode == 'angfreq':
            wlp, wls, wli = bop.w2wl([pump, signal, idler])
            wp, ws, wi = pump, signal, idler
            spwl = bop.w2wl_std(wp, sigma_pump)
            spw = sigma_pump

        return [wp, spw, ws, wi], [wlp, spwl, wls, wli]

    else:
        raise ValueError('Number of arguments is not 2, 3 or 4.')


def noperm2perm(config_list):
    
    """
    Remove duplicates from a configuration list and then returns a list where
    all non-degenerate configurations appear in their two forms.
    """
    
    ret = []
    
    # remove duplicates
    config_list = list(dict.fromkeys(config_list))

    for conf in config_list:
        ret.append(conf)
        
        if not is_degen(conf):
            rev_conf = reverse_config(conf)
            
            if rev_conf in config_list:
                config_list.remove(rev_conf)
            
            ret.append(rev_conf)
            
    return ret


def simplify_nondegens(config_list):
    
    """
    Remove duplicates from a configuration list and then returns a list where
    all non-degenerate configurations appear in only one of their forms.
    """
    
    ret = []
    # remove duplicates
    config_list = list(dict.fromkeys(config_list))

    for conf in config_list:
        ret.append(conf)
        if not is_degen(conf):
            rev_conf = reverse_config(conf)
            if rev_conf in config_list:
                config_list.remove(rev_conf)
            
    return ret



def parse_configs(configs, material, signal_mode, sig_eq_idl, 
                  disallow_perms=False):

    if configs.lower() in 'all type0 type1 type2':

        conf_mode = configs

        if signal_mode == 'sweep':
            try:
                confs_arg = material.eff_confs if sig_eq_idl else \
                            material.eff_confs_perm

            except KeyError:
                # material has no defined possible configurations
                print('The possible configurations of non-negative effective d'
                      'were not defined for this material! All configurations will'
                      'be used but note some of them may not be used for SPDC.')
                confs_arg = ALL_CONFS if sig_eq_idl else ALL_CONFS_PERM

        elif signal_mode == 'match':
            try:
                confs_arg = material.eff_confs_perm
            except KeyError:
                # material has no defined possible configurations
                print('The possible configurations of non-negative effective d'
                      'were not defined for this material! All configurations will'
                      'be used but note some of them may not be used for SPDC.')
                confs_arg = ALL_CONFS_PERM

        if 'type' in conf_mode:
            confs_arg = [ c for c in confs_arg if conf2PMtype(c) == float(conf_mode[-1]) ]


    elif isinstance(configs, str):
        
        if disallow_perms or (sig_eq_idl and signal_mode == 'sweep'):
            # the configurations are exactly as they are supposed to be
            # so we will not allow the splitting of the nondegenerate configs
            confs_arg = simplify_nondegens(configs.split())
        
        else:
            # we will split all the nonpermuted nondegenerate configuration 
            # meaning that eg 'yyz' will become 'yyz' and 'yzy'
            confs_arg = noperm2perm(configs.split())

    return confs_arg



def count_configs(config_list, sweep_quad_window):
    nconfs = 0
    for c in config_list:
        if sweep_quad_window and not is_degen(c):
            nconfs += 2
        else:
            nconfs += 1

    return nconfs
        
    
def parse_opt_par(opt_par_value, other_value, opt_par):
    
    if opt_par == 'crystal_length':
        return opt_par_value, other_value
    elif opt_par == 'pump_FWHM':
        return other_value, opt_par_value
    else:
        raise ValueError('Optimization parameter must be \'crystal_length\''
                         'or \'pump_FWHM\'.')


def parse_refr_inds_string(refr_ind):
    if '_' in refr_ind:
        return refr_ind.split('_')
    else:
        return refr_ind


def reverse_config(config):
    sep = '_' if '_' in config else ''
    n1, n2, n3 = config if sep == '' else config.split(sep)
    return '{:s}{:s}{:s}{:s}{:s}'.format(n1, sep, n3, sep, n2)
    

def is_degen(config):

    if isinstance(config, (tuple, list)):

        return (config[1] == config[2])

    elif isinstance(config, str):
        
        sep = '/' if '/' in config else '_' if '_' in config else ''
        
        n1, n2, n3 = config  if sep == '' else config.split(sep)
        
        return (n2 == n3)


def conf2PMtype(conf_str):
    sep = '_' if '_' in conf_str else ''
    n1, n2, n3 = conf_str if sep == '' else conf_str.split(sep)
    PM_type = 0 if (n1==n2 and n2==n3) else 1 if n2==n3 else 2
    
    return PM_type


def parse_header(folder_name):
    
    """
    Example of a header:
    # Simulation start: 23/07/2022 11:18:56
    # Simulation end: 23/07/2022 11:19:16  
    # Material: ppLN at 25 degrees Celsius
    # Configurations: nx_nx_nz nx_nx_nx nz_nx_nx nz_nz_nz
    # Pump wavelength: given by energy conservation
    # Signal mode: sweep with signals equal to idlers
    # Optimization parameter: crystal length
    # N points (signals, idlers, opt parameter): (3, 3, 2)
    # Optimization criteria: JSA_purity (lines 7-11) / JSI_purity (lines 12-16) / abs(JSA)_purity (lines 17-21)
    """

    lines = []
    with open(os.path.join(folder_name, 'summary.txt')) as f:
        for _ in range(10):
            lines.append(f.readline())

    mat, tmp = lines[2][12:].replace('\n', '').split(' at ')
    
    mat = sett.MATERIALS[mat]
    mat.T = tmp
    
    tmp = float(tmp.split(' degrees')[0])
    txts = lines[3][18:].replace('\n', '').split(' ')
    wl_p = lines[4][19:].replace('\n', '')
    sig_mode = lines[5][15:].replace('\n', '')
    opt_par = lines[6][26:].replace('\n', '')

    if 'given by energy conservation' in wl_p:
        wl_p = None
    else:
        wl_p = float(wl_p)

    str_crits = lines[8][25:].replace('\n', '').split(') / ')
    list_crits = [ crit.split(' (')[0] for crit in str_crits ]
    
    sig_eq_idl = ('with signals equal to idlers' in sig_mode)
    sig_mode = sig_mode[:5]
    confs = noperm2perm(txts) if sig_eq_idl else txts

    return mat, txts, wl_p, sig_mode, opt_par, list_crits, confs


def parse_crossed_optimization(values, subfolder_pattern, fields, main_dir='.'):
    
    indices = [ list(range(len(el))) for el in values ]
    indices_tuples = product(*indices)
    data_tuples = product(*values)
    
    results = np.zeros( [len(el) for el in values] + [len(fields)] )
    
    for index_tuple, data_tuple in zip(indices_tuples, data_tuples):
        
        summary_path = os.path.join(main_dir,
                                    subfolder_pattern.format(*data_tuple),
                                    'summary.txt')
        
        
        # immediately grab only the first data
        current_data = np.atleast_1d(np.genfromtxt(summary_path,
                                                   dtype=utils.DTYPE_LIST,
                                                   delimiter=', '))
        
        ind = np.where(current_data['confs'] == 'yyz')[0][0]
        
        # print([ current_data[ind][field] for field in fields ])
        
        results[ (*index_tuple, slice(None)) ] = [ current_data[ind][field] for field in fields ]
        
        
    return results
        
        
        
        


        
        
        
        
    
    
    