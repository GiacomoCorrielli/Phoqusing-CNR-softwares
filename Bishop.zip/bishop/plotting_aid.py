import os

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

import numpy as np

import bishop.settings as us
import bishop.parsing_functions as parse
import bishop.objective_function as obj
import bishop.base_functions as base
import bishop.base_optics as bop
import bishop.utilities as utils

from mpl_toolkits.axes_grid1 import make_axes_locatable


def update_plt_params(latex):
    
    if latex: 
        params = {'text.usetex' : True,
                  'text.latex.preamble': r"\usepackage{lmodern} \usepackage{siunitx}"}
    else:
        params = {'text.usetex' : False,
                  'font.family': 'sans-serif',
                  'font.serif': 'Arial'}

    plt.rcParams.update(params)


def plot_single_graph(data, 
                      share_y=True,
                      graph_title='', annot_text='',
                      axis='wavelength',
                      save_path=None,
                      colorbar='',
                      get_handles=False,
                      one_column=False,
                      aspect_ratio='auto',
                      colorbar_title='',
                      colorbar_lims=None,
                      **kwargs):
    
    
    """
        Plot a single graph. ALL PLOTS are made in the angular frequency
        domain, what can differ is the labels that are made in the axes.

        Inputs:
        =======
        
        data         == list containing Xdata, Ydata and Zdata
        (list)

        window_title == relevant only if the figure is to be shown and
        (string)        not saved 

        graph_title == 

    """
    
    transform_labels = (axis == 'wavelength')
    invert_axes = (axis == 'wavelength')
    
    update_plt_params(us.USE_LATEX)
    
    axis_titles = us.AXIS_TITLES.get(axis, axis) if axis else ['', '']
    xaxis_title, yaxis_title = axis_titles
    
    if not isinstance(data[0], list):
        data = [data]

    Nplots = len(data)
    
    if colorbar_lims is None:
        colorbar_lims = Nplots*[None]  
    elif isinstance(colorbar_lims, list) and \
         isinstance(colorbar_lims[0], (int, float)):
        colorbar_lims = Nplots*[colorbar_lims]
        
    if isinstance(annot_text, str):
        annot_text = Nplots*[annot_text]
    if isinstance(graph_title, str):
        graph_title = Nplots*[graph_title]
    if isinstance(transform_labels, bool):
        transform_labels = Nplots*[transform_labels]

    fig_ind_size = 10
    fig, axs = plt.subplots(1, Nplots, sharey=share_y, 
                            figsize=(Nplots*fig_ind_size+fig_ind_size/5, 
                                     fig_ind_size))
    
    # copies to pass onto the transform labels
    cp_fig, cp_axs = plt.subplots(1, Nplots, sharey=share_y, 
                                  figsize=(Nplots*fig_ind_size+fig_ind_size/5, 
                                           fig_ind_size))


    if Nplots == 1:
        axs = [axs]
        cp_axs = [cp_axs]
    else:
        axs = axs.ravel()
        cp_axs = cp_axs.ravel()
    
    if aspect_ratio == 'unequal' or one_column:
        use_equal = False
    elif aspect_ratio == 'equal':
        use_equal = True
    else:
        if (np.max(data[0][0])-np.min(data[0][0])) == 0.:
            # only one x value, plot with unequal AR
            use_equal = False
        else:
            aratio = (np.max(data[0][1])-np.min(data[0][1]))/\
                     (np.max(data[0][0])-np.min(data[0][0]))
            if (aratio < 0.25) or (aratio > 4) or one_column:
                use_equal = False
            else:
                use_equal = True
    
    i_max = len(data) - 1
    for i, (cd, ct, ca, cax, ctl, caux, cbl) in enumerate(zip(data, graph_title, 
                                                              annot_text, axs, 
                                                              transform_labels, 
                                                              cp_axs, 
                                                              colorbar_lims)):
        
        if (i == 0):
            # only add colorbar once, only add label for y once, only invert
            # the y axis once (it is shared so affects all)

            cax.set_ylabel(yaxis_title, fontsize=28)

            if (colorbar == 'one_large'):
                
                cb_ax = fig.add_axes([0.91, 0.125, 0.0075, 0.7])
                cb_ax.tick_params(labelsize=24)
            
                if colorbar_title:
                    cb_ax.set_ylabel(colorbar_title, fontsize=24, rotation=270)

        # fig, ax = plt.subplots(1)

        cax.set_title(ct, fontsize=30)
        cax.set_xlabel(xaxis_title, fontsize=28)
        cax.tick_params(axis='both', which='major', labelsize=24)
        caux.tick_params(axis='both', which='major', labelsize=24)

        #cax.tick_params(axis='both', which='minor', labelsize=16)

        if use_equal:
            cax.set_aspect('equal')

        # implement the changes to the canvas
        fig.canvas.draw()

        if ctl:
            transform_axis_labels(cd, fig, cax, aux=(cp_fig, caux), 
                                  use_equal=use_equal)
        
        # extend all data by one
        nr, nc = np.shape(cd[0])

        #print(cd[0], cd[1], cd[2])

        delta_y = cd[1][1,0] - cd[1][0,0]
            
        delta_x = 1 if np.shape(cd[0])[1] == 1 else (cd[0][0,1]-cd[0][0,0])
        
        yy = np.append(cd[1], [cd[1][-1, :]+delta_y], axis=0) - delta_y/2
        yy = np.append(yy, np.array([yy[:,-1]]).transpose(), axis=1)
        
        xx = np.append(cd[0], np.array([cd[0][:, -1]+delta_x]).transpose(), axis=1) - delta_x/2
        xx = np.append(xx, np.array([xx[-1, :]]), axis=0)
        
        if len(np.shape(cd[2])) == 1.:
            # means that it is a row vector, convert to col vector
            cd[2] = np.atleast_2d(cd[2]).transpose()
        
        
        if cbl is not None:
            im = cax.pcolormesh(xx, yy, cd[2], shading='flat', 
                                vmin=cbl[0], vmax=cbl[1], **kwargs)
        else:
            im = cax.pcolormesh(xx, yy, cd[2], shading='flat', **kwargs)
        
        if (colorbar == 'all'):
            # each subplot gets a colorbar
            divider = make_axes_locatable(cax)
            cb_ax = divider.append_axes("right", size="5%", pad=0.05)
            cb_ax.tick_params(labelsize=24)
            fig.colorbar(im, cax=cb_ax)

            if colorbar_title:
                cb_ax.set_ylabel(colorbar_title, fontsize=24, rotation=270)

        elif (colorbar == 'one') and i==i_max:
            # each subplot gets a colorbar
            divider = make_axes_locatable(cax)
            cb_ax = divider.append_axes("right", size="5%", pad=0.05)
            cb_ax.tick_params(labelsize=24)
        
            fig.colorbar(im, cax=cb_ax)

            if colorbar_title:
                cb_ax.set_ylabel(colorbar_title, fontsize=30, rotation=270)          

        
        if invert_axes:
            if (not share_y) or (share_y and i == 0):
                cax.invert_yaxis()

            cax.invert_xaxis()
        
        cax.annotate(ca,
                     xycoords='axes fraction', xy=(0.90, 0.95),
                     color='white', ha='right', va='top',
                     size=40)


    r_marg = 0.85 if colorbar else 0.87
    
    plt.subplots_adjust(left=0.13,
                        bottom=0.05, 
                        right=r_marg, 
                        top=0.95, 
                        wspace=0.2, 
                        hspace=0.1)
    
    plt.close(cp_fig)

    if save_path is not None:
        plt.savefig(save_path, dpi=us.PLOTS_SAVE_DPI, bbox_inches='tight')
        plt.close(fig)

        if get_handles:
            return fig, axs
        
    else:
        return fig, axs



def transform_axis_labels(data, fig_plot, ax_plot, lims=None, aux=None, use_equal=False):
    
    if aux is None:
        fig_aux, ax_aux = plt.subplots(1)
    else:
        fig_aux, ax_aux = aux

    
    im_aux = ax_aux.pcolormesh(bop.w2wl(data[0]), 
                               bop.w2wl(data[1]), 
                               data[2], 
                               shading='auto')
    
    xlims = ax_aux.get_xlim()
    ylims = ax_aux.get_ylim()

    # auto_ticker = ticker.AutoLocator()
    # auto_ticker.axis = ax

    #ax.xaxis.set_major_locator(ticker.AutoLocator())
    #ax.yaxis.set_major_locator(ticker.AutoLocator())
    
    if use_equal:
        xlims_orig = ax_plot.get_xlim()
        ylims_orig = ax_plot.get_ylim()

        xts_vals_orig = np.array( ax_plot.get_xticks() )  # number of ticks in the original angfreq plot
        yts_vals_orig = np.array( ax_plot.get_yticks() )  # number of ticks in the original angfreq plot
        
        xts_vals_orig = xts_vals_orig[(xlims_orig[1] > xts_vals_orig) & (xts_vals_orig > xlims_orig[0])]
        yts_vals_orig = yts_vals_orig[(ylims_orig[1] > yts_vals_orig) & (yts_vals_orig > ylims_orig[0])]

        n_xts_orig = len(xts_vals_orig)
        n_yts_orig = len(yts_vals_orig)

        xts_vals = np.array( ax_aux.get_xticks() )  # comes in wl
        yts_vals = np.array( ax_aux.get_yticks() )  # comes in wl

        njump = 3
        ax_aux.xaxis.set_major_locator(ticker.MaxNLocator(nbins=njump*(n_xts_orig)))
        ax_aux.yaxis.set_major_locator(ticker.MaxNLocator(nbins=njump*(n_yts_orig)))   

    else:
        njump = 1

    fig_aux.canvas.draw()

    xts_strs_tex = np.array([label.get_text() for label in ax_aux.get_xticklabels()])
    xts_strs = ["".join(c for c in label.get_text() if c.isdigit() or c == ".") 
                for label in ax_aux.get_xticklabels()]
    xts_vals = np.array([float(xts_str) for xts_str in xts_strs])
    
    yts_strs_tex = np.array([label.get_text() for label in ax_aux.get_yticklabels()])
    yts_strs = ["".join(c for c in label.get_text() if c.isdigit() or c == ".") 
                for label in ax_aux.get_yticklabels()]
    yts_vals = np.array([float(yts_str) for yts_str in yts_strs])
    
    # ATTENZIONE QUA !!!
    xts_strs_tex = xts_strs_tex[(xlims[1] > xts_vals) & (xts_vals > xlims[0])][::-1]
    yts_strs_tex = yts_strs_tex[(ylims[1] > yts_vals) & (yts_vals > ylims[0])][::-1]
    
    xts_vals = xts_vals[(xlims[1] > xts_vals) & (xts_vals > xlims[0])]
    yts_vals = yts_vals[(ylims[1] > yts_vals) & (yts_vals > ylims[0])]

    # xticks_no_zero = [xtick for xtick in ax_aux.get_xticks().tolist() if xtick > 0.]
    # yticks_no_zero = [ytick for ytick in ax_aux.get_yticks().tolist() if ytick > 0.]
    
    # print([f'{tk:2e}' for tk in bop.wl2w(xts_vals[::njump])])
    
    ax_plot.xaxis.set_major_locator(ticker.FixedLocator(bop.wl2w(xts_vals[::njump])))
    ax_plot.set_xticklabels(xts_strs_tex[::njump])

    ax_plot.yaxis.set_major_locator(ticker.FixedLocator(bop.wl2w(yts_vals[::njump])))
    ax_plot.set_yticklabels(yts_strs_tex[::njump])
    

    

def fill_corr_dict(folder_name, config_str, plots_list):

    corr_dict = {}

    # has to be corrected for several optcriteria but OK so far...
    for plot_name in plots_list:

        txt_filename = f'{config_str}_{plot_name}.txt'
    
        gen_arr = np.genfromtxt(os.path.join(folder_name, txt_filename))
        
        '''        
        if plot_name == 'slope':
            marker = (gen_arr < 1) & (gen_arr > -1)
            gen_arr[marker] = 1/gen_arr[marker]
        '''

        corr_dict[plot_name] = gen_arr

    return corr_dict


def fill_mask_dict(plots_list, corr_dict, nrows):

    mask_dict = {}

    for plot_name in plots_list:

        mask_dict[plot_name] = False
    
    
    if 'slope' in plots_list:
        slopes = corr_dict['slope'][0:nrows]
        mask_dict['slope'] = np.logical_or( slopes > 100, slopes < -100 )
        
    if 'poling_period' in plots_list:
        ppers = corr_dict['poling_period'][0:nrows] 
        mask_dict['poling_period'] = np.logical_or( ppers > 300, ppers < -300 )
        
    
    return mask_dict


def make_sweep_plots(folder_name, plots, save_prefix=''):
    
    """
    Create sweep plots. Sweep plots are exclusive of wavelength sweeps, series 
    of simulations where a mesh of signal and idler wavelengths is tested. The 
    sweep plots are one png image for each configuration and criterium, and are
    placed in a directory called sweep_plots inside the given folder.
    
    Parameters
    ----------
    folder_name : str
        Path to a folder that must contain a summary.txt file, and the corres-
        ponding simulation results.
        
    plots : str
        The plots to do, in the order which they are intended, and separated by
        spaces.
        
    save_prefix : str
        Expression that precedes the name of the file. 
    
    """
    
    subfolder_path = os.path.join(folder_name, 'sweep_plots')
    if (not os.path.exists(subfolder_path)):
        os.makedirs(subfolder_path)
    
    mat, txts, wl_p, sig_mode, opt_par, crits, confs = parse.parse_header(folder_name)

    if opt_par == 'NO':
        ncrits = 1.
        
    ncrits = len(crits)

    # print(f'Material: {mat}\nConfigurations: {confs}\nSignal mode: {sig_mode}')

    sig_wls_mg = np.genfromtxt(os.path.join(folder_name, 'signal_wls.txt'))
    idl_wls_mg = np.genfromtxt(os.path.join(folder_name, 'idler_wls.txt'))

    nrows, ncols = np.shape(sig_wls_mg)

    sig_wls = sig_wls_mg[0, :]
    idl_wls = idl_wls_mg[:, 0]
    sig_eq_idl = np.all(sig_wls == idl_wls)

    # idl_min, idl_max = idl_wls[-1], idl_wls[0]
    # sig_min, sig_max = sig_wls[-1], sig_wls[0]

    if (sig_mode == 'sweep'):
        xx, yy = np.meshgrid(sig_wls, idl_wls)
    elif (sig_mode == 'match'):
        xx, yy = np.meshgrid(np.array([1.]), idl_wls)

    if 'PEF' in plots:
        do_isopumps = True
        auto_isopumps = True
        plots_list_PEF = []

    else:
        # isopumps at given pump wavelengths
        auto_isopumps = False
        plots_list_PEF = [float(k[3:]) for k in plots.split() if ('PEF' in k)]
        do_isopumps = (len(plots_list_PEF) > 0)
        
    
    plots_list = [key for key in plots.split() if ('PEF' not in key)]
    
    
    for config_str in txts:

        npstr, nsstr, nistr = parse.parse_refr_inds_string(config_str)

        char = '_' if ('_' in config_str) else ''
        swap_str = '{:s}{:s}{:s}{:s}{:s}'.format(npstr, char, nistr, char, nsstr)

        if (sig_eq_idl and sig_mode == 'sweep' and nsstr != nistr):
            print(f'Starting the sweep plots for configurations {config_str}'
                  f' and {swap_str}')
        else:
            print(f'Starting the sweep plots for configuration {config_str}')

        if sig_eq_idl and sig_mode == 'sweep' and nsstr == nistr:
            # the ones to mask
            mask_wls = (sig_wls_mg > idl_wls_mg)
        else:
            mask_wls = False

        # fill in the correspondances dict
        corr_dict = fill_corr_dict(folder_name, config_str, plots_list)
        mask_dict = fill_mask_dict(plots_list, corr_dict, nrows)
        
        for k in range(ncrits):
            
            data_to_plot = [ [ xx, yy,
                               np.ma.masked_array(corr_dict[p][k*nrows:(k+1)*nrows, :],
                                                  mask=np.logical_or(mask_dict[p],
                                                                     mask_wls)) ]
                               for p in plots_list]    

            
            graph_titles = [ us.GRAPH_TITLES_DICT[plot_name] 
                             if plot_name != 'opt_par'
                             else us.GRAPH_TITLES_DICT[opt_par] 
                             for plot_name in plots_list ]

            path = os.path.join(subfolder_path,
                                f'{save_prefix}{config_str}_optcrit_{crits[k]}.png')

            fig, axs = plot_single_graph(data_to_plot,
                                         share_y=True,
                                         axis='true wavelength',
                                         colorbar='all',
                                         graph_title=graph_titles,
                                         one_column=(sig_mode=='match'),
                                         get_handles=True)
                                         #vmin=0.7, vmax=1. )
            
            if do_isopumps:
                fig, axs = plot_isopump_curves(fig, axs,
                                               wls_list=plots_list_PEF,
                                               auto_isopumps=auto_isopumps)
                
            plt.savefig(path, dpi=us.SWEEP_PLOTS_DPI, bbox_inches='tight')
            plt.close(fig)

    return



def make_joint_spectral_plots(folder_name, plots_string,
                              show_lines=False, save_prefix='',
                              **kwargs):
    
   
    window_lims = kwargs.get('window limits', False)
    these_lims = window_lims
    
    scale_type = kwargs.get('scale type', 'sig-idl')
    
    subfolder_path = os.path.join(folder_name, 'joint_spectral_plots')
    if (not os.path.exists(subfolder_path)):
        os.makedirs(subfolder_path)

    mat, txts, wl_p, sig_mode, opt_par, crits, confs = parse.parse_header(folder_name)
    
    ncs = 1
    trials_data = np.atleast_1d( np.genfromtxt(f'{folder_name}/summary.txt',
                                               dtype=utils.DTYPE_LIST,
                                               delimiter=', ') )
    pump = None
    
    for i_crit, crit in enumerate(crits):

        for i_conf in range(len(confs)):
        
            ind_plots = i_crit*ncs + i_conf
            
            # A = trials_data[ind_plots]['A']
            # B = trials_data[ind_plots]['B']
            conf_str = trials_data[ind_plots]['confs']
            
            wl_p_std = trials_data[ind_plots]['sigma_pump'] / 2.355 * np.sqrt(2)
            wl_s = trials_data[ind_plots]['wls_signal']
            wl_i = trials_data[ind_plots]['wls_idler']
            
            L = trials_data[ind_plots]['lengths']
            pper = trials_data[ind_plots]['poling_period']            
            pJSI = trials_data[ind_plots]['pJSI']
            pJSA = trials_data[ind_plots]['pJSA']
            # gJSA = trials_data[ind_plots]['JSA_gamma']
            
            dict_wls = { k:v for (k, v) in zip(list(conf_str)[1:3], [wl_s, wl_i]) }
                    
            if window_lims:
                dict_wdw = { k:v for (k, v) in zip(list(conf_str)[1:3], window_lims)}
            
            
            if scale_type != "sig-idl":
                # in this case the scale_type is the configuration
                wl_1 = dict_wls[scale_type[1]]
                wl_2 = dict_wls[scale_type[2]]
                plt_conf_str = scale_type

                
                if window_lims:
                    wdw_1 = dict_wdw[scale_type[1]]
                    wdw_2 = dict_wdw[scale_type[2]]
                    these_lims = [wdw_1, wdw_2]
            
            else:
                [ wl_1, wl_2, plt_conf_str ] = [ wl_s, wl_i, conf_str ]

            wl_p = utils.hmean(wl_1, wl_2) if (pump is None) else pump

            save_path = os.path.join(subfolder_path,
                                     f'{save_prefix}best_for_'
                                     f'{conf_str}_crit_{crit}.png')
            
            mat.conf = plt_conf_str
            mat.L = L
            mat.pper = pper
            
            make_one_joint_spectral_plot(wl_p, wl_p_std, wl_1, wl_2,
                                         mat, [pJSA, pJSI, 0],
                                         plots_string, save_path,
                                         input_mode='wavelength',
                                         show_lines=show_lines,
                                         window_lims=these_lims,
                                         **kwargs)

    return



def make_one_joint_spectral_plot(pump, sigma_pump,
                                 signal, idler,
                                 mat, purities,
                                 plots_string,
                                 save_path,
                                 input_mode='angfreq',
                                 show_lines=False,
                                 **kwargs):
    
    window_lims = kwargs.get('window_lims', False)
    
    [wp, spw, ws, wi], [wlp, spwl, wls, wli] = parse.parse_args(pump, 
                                                                sigma_pump, 
                                                                signal, idler,
                                                                input_mode=input_mode)

    pJSA, pJSI, pJSAnp = purities
    
    print('FILE pJSA: ', pJSA)
    
    [pl_s, pl_i, pe, pm_sep, pm_app_sep, pts] = base.get_JSFs(wlp, spwl,
                                                              wls, wli,
                                                              mat,
                                                              mode='wavelength',
                                                              output='verts',
                                                              split_pm=True,
                                                              npts=us.JOINT_SPECTRAL_PLOTS_POINTS,
                                                              resolution=us.OPT_LOOP_RESOLUTION,
                                                              lims=window_lims,
                                                              verbose=True)
    
    
    pm = pm_sep[0] * pm_sep[1]
    pm_app = pm_app_sep[0] * pm_app_sep[1]
    
    JSA_noph = pm_sep[0] * pe
    JSA_app_noph = pm_app_sep[0]
    
    A, B = mat.A_and_B(wlp, wls, wli, mode='wavelength')

    JSA_abs = np.abs(pm*pe)
    JSA_abs_app = np.abs(pm_app*pe)
    
    JSI = JSA_abs**2
    JSI_app = JSA_abs_app**2

    # JSA_complex = pm_app * pe
    # F = JSA_complex.astype(np.complex128)
    # F_H = np.conjugate(np.transpose(F)).astype(np.complex128)
    # opdist_mtx = dot_py(F, F_H) - dot_py(F_H, F) 

    pl_s_lin = pl_s[0, :]
    pl_i_lin = pl_i[:, 0]

    data_dict = { 'PEF': pe,
                  'PEFSq': pe**2,
                  'PMF': np.abs(pm),
                  'PMFApp': np.abs(pm_app),
                  'PMFSq': np.abs(pm)**2,
                  'PMFAppSq': np.abs(pm_app)**2,
                  'JSA': JSA_abs,
                  'JSAnp': JSA_noph,
                  'JSAApp': JSA_abs_app,
                  'JSAAppNp': JSA_app_noph,
                  'JSI': JSI,
                  'JSIApp': JSI_app }


    pJSA = 1/obj.get_K_eig_numba(utils.normal(pm*pe))
    pJSAabs = 1/obj.get_K_eig_numba(utils.normal(JSA_abs)) 
    pJSI = 1/obj.get_K_eig_numba(utils.normal(JSI))
    pJSAnoph = 1/obj.get_K_eig_numba(utils.normal(JSA_noph))
    
    ann_pJSA = r'$pJSA = $' + r' ${:.3f}$'.format(pJSA)
    ann_pJSI = r'$pJSI = $' + r' ${:.3f}$'.format(pJSI)
    ann_pJSAnoph = r'$pJSAnp = $' + r' ${:.3f}$'.format(pJSAnoph)

    ann_dict = { 'JSA': ann_pJSA, 
                 'JSAApp': ann_pJSA,
                 'JSI': ann_pJSI,
                 'JSIApp': ann_pJSI,
                 'JSAnp': ann_pJSAnoph,
                 'JSAAppNp': ann_pJSAnoph }
    
    
    print('PLOT pJSA: ', pJSAnoph)
    
    
    keys = plots_string.split(' ')
    gplots = [ [pl_s, pl_i, data_dict[k]] for k in keys ]
    gtitles = [ us.tit_dict[k] for k in keys ]
    gannots = [ ann_dict.get(k, '') for k in keys ]

    if show_lines:
        f, axxs = plot_single_graph(gplots, graph_title=gtitles,
                                    annot_text=gannots,
                                    axis=us.JOINT_SPECTRAL_PLOTS_AXIS,
                                    share_y=False,
                                    aspect_ratio=us.JOINT_SPECTRAL_PLOTS_AR,
                                    colorbar=us.JOINT_SPECTRAL_PLOTS_CB_TYPE,
                                    get_handles=True)

        for ax in axxs:
            
            L = mat.L
            
            ax.plot(pl_s_lin, wp-pl_s_lin+np.sqrt(2*us.MARGIN_PEF*spw**2),
                    color='white', linestyle='dashed')    
            ax.plot(pl_s_lin, wp-pl_s_lin-np.sqrt(2*us.MARGIN_PEF*spw**2),
                    color='white', linestyle='dashed')

            ax.plot(pl_s_lin, wi-A/B*(pl_s_lin-ws)+2*2*us.PI/B/L,
                    color='white', linestyle='dashed')
            ax.plot(pl_s_lin, wi-A/B*(pl_s_lin-ws)-2*2*us.PI/B/L,
                    color='white', linestyle='dashed')

            for p in pts:
                ax.plot(p[0], p[1], marker='o', color='white', markersize=7)
            
            ax.set_xlim(pl_s_lin[[0, -1]])
            ax.set_ylim(pl_i_lin[[0, -1]])

        
        plt.savefig(save_path, dpi=us.JOINT_SPECTRAL_PLOTS_DPI, 
                    bbox_inches='tight')
        plt.close(f)
        
    else:
        plot_single_graph(gplots, 
                          graph_title=gtitles,
                          annot_text=gannots,
                          axis=us.JOINT_SPECTRAL_PLOTS_AXIS,
                          share_y=False,
                          aspect_ratio=us.JOINT_SPECTRAL_PLOTS_AR,
                          colorbar=us.JOINT_SPECTRAL_PLOTS_CB_TYPE,
                          save_path=save_path)



def plot_isopump_curves(fig, axs, wls_list=[], auto_isopumps=False, legend=False):
    
    sig_min, sig_max = axs[0].get_xlim()
    idl_min, idl_max = axs[0].get_ylim()

    if auto_isopumps:
        # locate automatically the PEFs using the edges of the axis
        urc = [sig_min + 0.9*(sig_max-sig_min), idl_min + 0.9*(idl_max-idl_min)]
        llc = [sig_min + 0.1*(sig_max-sig_min), idl_min + 0.1*(idl_max-idl_min)]

        wls_list = np.linspace( utils.hmean(llc[0], llc[1]),
                                utils.hmean(urc[0], urc[1]),
                                us.NUMBER_OF_ISOPUMP_CURVES )

    for ax in axs:
        
        for i, wlp_plot in enumerate(wls_list):

            wl_min = max([1.01*wlp_plot, sig_min])
            wl_max = sig_max

            wls_plot = np.linspace(wl_min, wl_max, 30)

            wli_plot = 1/(1/wlp_plot - 1/wls_plot)
            
            if auto_isopumps or legend:
                    
                if (i==0) or (i==len(wls_list)-1):
                    label = f'wlp = {wlp_plot:.3f} um'
                    linestyle = 'dashdot'
                else:
                    label = ''
                    linestyle = 'dotted'
                
            else:
                label = ''
                linestyle = 'dotted'
                
            
            ax.plot(wls_plot, wli_plot, c='black', 
                    marker=None, linewidth=2, linestyle=linestyle,
                    label=label)
            
        if auto_isopumps or legend:
            ax.legend(fontsize=18)

        ax.set_xlim(sig_min, sig_max)
        ax.set_ylim(idl_min, idl_max)

    return fig, axs
