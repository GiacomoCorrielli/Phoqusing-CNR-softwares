import os
import numpy as np
from datetime import datetime

import bishop.plotting_aid as plaid
import bishop.base_functions as base
import bishop.base_optics as bop
import bishop.parsing_functions as parse
import bishop.settings as us
import bishop.parameters as pars
from bishop.objective_function import get_K_eig_numba, dot_py
import bishop.utilities as utils 


def communicate_simulation_type(sim_type, sm, dims, par_name, par_mode):
    
    ns, ni, npar = dims
    
    words = {'sweep': [f'crossed with all {ni} idlers', 
                       f'bidimensional {ns}x{ni}'],
             'match': ['matched with the respective idler', 
                       f'linear size {ns}'],
             'auto': 'automatically selected',
             'user': 'user defined'}
    
    if sim_type == 'optimization':
        print((f'This simulation is an optimization in {sm} mode. '
               f'All {ns} signals will be {words[sm][0]}, resulting in a '
               f'{words[sm][1]} mesh of spectral points. '
               f'The parameter to optimize is {par_name}, for each '
               f'signal-idler pair, {npar} {words[par_mode]} test parameters '
               f'will be used. '
               f'Sweep plots and final plots will be generated if the user so '
               f'specified.\n\n'))
               
    elif sim_type == 'single_trial':
        print(('This simulation is a single trial, meaning that a crystal ' 
               'with a defined length will be simulated with a pump of a '
               'defined spectral width. Sweep plots will NOT be generated. '
               'Final plots WILL be generated if the user so specified.\n\n'))
        
    elif sim_type == 'preliminary_sweep':
        print(('This simulation is a preliminary sweep, because no optimization '
               'parameter was given. This means only the slope and the poling '
               'periods will be calculated. '
               'Sweep plots will be generated if the user specified so. '
               'Final plots will NOT be generated.\n\n'))
        
        
    
def study_configurations(pump_wl, signal_wls, idler_wls,
                         signal_mode='',
                         optimization={},
                         crystal={},
                         save={},
                         filtering={},
                         **kwargs):
    """
    Runs one sweep of the signal and idler wavelengths and for a fixed 
    material and configuration. Saves all computed data in a txt file.
    
    Parameters
    ----------
    
    pump_wl (float or str)
        If float, it must be the pump wavelength in um.
        Only accepted str is \'match\', in which case the program chooses, for
        every signal and idler, the pump wavelength determined by energy con-
        servation.
    
    signal_wls / idler_wls : float, np.ndarray, list or tuple (unit: um)
        Signal / idler wavelengths.
    
    signal_mode : str
        Only relevant when both signal_wls and idler_wls are iterables, in 
        which case this parameter must be given:
        \'sweep\' when it is intended to do all pairs of m signals and n idlers 
        given (in total m*n pairs)
        \'match\' when it is intended to do a one-to-one correspondance between
        the n signals and n idlers (in total n pairs). Note that this requires 
        the two iterables in question to have the same size!
    
    optimization : dict
        Dictionary with the following (mutually exclusive) mandatory keys:
        
        \'npoints\': int containing the number of test parameters to be used in
        the routine (either crystal lengths or pump widths). Unless 
        \'test_values\' are given, these points are automatically selected.
        
        \'test_values\': tuple, list, or np.ndarray containing the values of 
        the parameter to be tested. If provided, the \'npoints\' entry will be
        ignored, thereby using these values.
        
        the following optional keys:
        
        \'parameter\': the parameter to be optimized, it can be \'pump_FWHM\', 
        \'crystal_length\'. Defaults to the empty string (no optimization).
        
        \'crystal_length\': the length of the crystal (unit: um). Mandatory if 
        the \'parameter\' entry was set to \'pump_FWHM\'.
        
        \'pump_FWHM\': string containing the value of the pump FWHM in intensi-
        ty followed by a space and the unit of measurement (\'s\' or \'um\'). 
        Mandatory if the \'parameter\' entry was set to \'crystal_length\'.
        
        \'criteria\': string containing the objective function(s) to be maximi-
        zed (separated by space). Possible values are \'pJSA\' (JSA purity),
        \'pJSI\' (JSI purity) and \'pJSAnp\' (purity of JSA without phase term).
        Defaults to 'pJSA'.
        
        
    crystal : dict
        Dictionary with the following mandatory keys:
        
        \'material\': a bishop.materials.Material instance (material of the
        nonlinear crystal).
            
        \'temperature\': float, the temperature of the nonlinear crystal 
        (unit: ºC).
    
        and the following optional keys:
            
        \'configuration\': string with the test configurations. Available op-
        tions are \'all\', \'type0\', \'type1\', \'type2\', or a space separa-
        ted sequence of \'???\' where each ? can be x, y or z (but not 
        permutations of xyz). Defaults to \'all\' (all configurations with 
        nonzero nonlinear efficiency).
            
        \'forbid_perms\': bool, whether to forbid the exchange of signal and
        idler. Defaults to False.
    
    
    save : dict
        Dictionary with the following mandatory key:
        
        \'save_path\': string with the path to an existing folder or to a loca-
        tion where folder creation is allowed (if non existent, the folder will
        be created).
        
        and with the following optional keys:
        
        \'compute\': string with space separated data to compute. Poling period
        and slope are always calculated. If optimization criteria are provided,
        it is automatically added to the computed variables. All data present
        in this field will be saved. Check manual for available options.
        
        \'sweep_plots\': string with space separated sweep plots to be done, in
        the intended order left to right. Will be ignored (and no plots done) 
        if only one idler and one signal are provided. Check manual for avai-
        lable options. Defaults to the empty string.
        
        \'final_plots\': string with space separated final plots to be done, in
        the order of intended plotting. Will be ignored (and no plots done) if 
        the optimization is not triggered. Check manual for available options.
        Defaults to the empty string.
        
        \'final_plots_lines\': bool, whether to draw PEF and PMF bounding lines.
        
        \'prefix\': str, a prefix for all the generated txt files. 
        

    """
    
    parse.check_dict_integrities(optimization, crystal, save)
    
    # name of the file is the name of the last folder in the path
    #file_name = os.path.basename(os.path.normpath(folder_name))
    file_name = 'summary'
    
    folder_name = save.get('folder_name')
    if (folder_name is not None) and (not os.path.exists(folder_name)):
        os.makedirs(folder_name)

    material = crystal.get('material')
    material.set_temperature(crystal['temperature'])    
    forbid_perms = crystal.get('forbid_perms')

    print(("         O                                                            \n" 
           "       // \\\\                                                        \n" 
           "      /     \         WELCOME TO BISHOP, BIphoton State for Heralding \n"
           "    //       \\\\       by Optimization of Purity, a simulator of JSIs\n"
           "   /  BISHOP   \      and JSAs with purity maximization.              \n"
           "  /             \                                                     \n"
           "  \\\\  __   __  //     For informations contact please contact         \n"
           "   \ /  \ /  \ /      hugo.jorgedanobrega@polimi.it                   \n"
           "~~~~O    |    O~~~~                                                   \n"
           "     \__/ \__/                                                        \n"))
             
    
    
    print(f'Starting {material.name} at temperature {material.T}.\n\n')
    
    configs = crystal.get('configuration', '')

    if not configs:
        print(('No configurations given. All (d effective =/= 0) will be used.'
               'If you intend differently, use Ctrl+C to stop this and create '
               'an entry called \'configuration\' in the optimization dict.'
               'Available options are \'all\', \'type0\', \'type1\', \'type2\''
               'or a space-separated sequence of \'???\' where each ? can be'
               'x, y or z.\n'))
        configs = 'all'



    sig_eq_idl = np.all(signal_wls == idler_wls)

    # parse the data of the signal and idler wavelengths
    # basically 2 modes of operation:
    # Sweep: for each signal do each idler
    # Match: for each idler do the corresponding signal 
    #        (2 arrays have to be same size)
    if isinstance(signal_wls, float) and isinstance(idler_wls, 
                                                    (list, tuple, np.ndarray)):
        signal_mode = 'match'
        signal_wls = signal_wls * np.ones_like(idler_wls)
        npts_j = 1
    
    elif isinstance(idler_wls, float) and isinstance(signal_wls,
                                                     (list, tuple, np.ndarray)):
        signal_mode = 'match'
        temp = signal_wls
        signal_wls = idler_wls * np.ones_like(signal_wls)
        idler_wls = temp
        npts_j = 1

    elif isinstance(idler_wls, float) and isinstance(signal_wls, float):
        signal_mode = 'match'
        idler_wls = [ idler_wls ]
        signal_wls = [ signal_wls ]
        npts_j = 1

    else:
        # they are both array/list/tuple
        if signal_mode == 'match':
            
            # the two arrays have to be the same size!
            if len(signal_wls) != len(idler_wls):
                print('Signal and idler number of wavelengths have to be the '
                      'same in match mode.')
                return
             
        """
        # for compatibility with the skip condition 
        tmp = signal_wls
        signal_wls = idler_wls
        idler_wls = tmp
        """
        npts_j = len(signal_wls) if (signal_mode == 'sweep') else 1
    
    
    reverse_skip_cond = (np.max(signal_wls) > np.max(idler_wls)) and (signal_mode == 'sweep')
    
    npts_i = len(idler_wls)
    
    sweep_sq_wdw = sig_eq_idl and (signal_mode == 'sweep')
    
    list_with_configs = parse.parse_configs(configs, material, 
                                            signal_mode, sig_eq_idl,
                                            forbid_perms)
    
    material.check_configurations(list_with_configs)
  
    string_with_configs = ' '.join(list_with_configs)
    
    nconfs = parse.count_configs(list_with_configs, sweep_sq_wdw)

    # in which conditions to enter the optimization loop?
    # 1. an optimization parameter is given AND
    # 2. the other parameter is given
    
        
    opt_values = optimization.get('test_values', False)
    
    if opt_values:
        opt_npoints = len(opt_values)
        par_mode = 'user'
    else:
        opt_npoints = optimization.get('npoints', 1)
        par_mode = 'auto'

    crystal_length = pars.Parameter('crystal_length', 
                                    optimization.get('crystal_length'),
                                    'um', 'optimization', float)
    
    pw = optimization.get('pump_FWHM')
    pw_unit = pw.split()[1] if pw else 'None'
    
    
    pump_FWHM = pars.Parameter('pump_FWHM', pw, pw_unit, 'optimization', str)
    
    compute = pars.Parameter('data to compute', save.get('compute'), 
                             None, 'data_to_save', list, 
                             default=['pJSA'], entry_name='compute')
    
    criteria = pars.Parameter('criteria', optimization.get('criteria'),
                              None, 'optimization', list,
                              availables='pJSA pJSI pJSAnp',
                              default=['pJSA'])
    
    opt_par_name = optimization.get('parameter')
    opt_par = pars.Parameter('variable to optimize', opt_par_name,
                             'str', 'optimization', str,
                             availables='crystal_length pump_FWHM')
    
    
    # a preliminary sweep is when no optimization parameter is given, in which
    # case the optimization will not follow, and only the slopes and the requi-
    # red poling periods will be calculated
    prelim_sweep = False
    
    save_final_plots = save.get('final_plots', '')
    show_lines = save.get('final_plots_lines', False)
    save_prefix = save.get('prefix', '')
    save_opt_logs = save.get('optlog', False)
    
    
    opt_par_poss = ['pump_FWHM', 'crystal_length']
    
    if opt_par_name:
        
        if npts_i == 1 and npts_j == 1:
            save_sweep_plots = set()
        else:
            save_sweep_plots = set((save.get('sweep_plots', '') +\
                                    ' poling_period slope opt_par').split())
        opt_par_poss.remove(opt_par_name)
        opt_other_par = (locals()[opt_par_poss[0]]).value
        simtype = 'optimization'

    elif pump_FWHM.is_defined() and crystal_length.is_defined():
        # both are defined, so do a single trial
        save_sweep_plots = {''}
        opt_values = crystal_length.value     
        opt_other_par = pump_FWHM.value
        material.set_length(crystal_length.value)
        opt_npoints = 1
        simtype = 'single_trial'


    else:
        # do not do the optimization
        save_these = {'poling_period', 'slope'}
        save_sweep_plots = set((save.get('sweep_plots', ''))) & save_these
        save_final_plots = {''}
        simtype = 'preliminary_sweep'
    
    if simtype != 'preliminary_sweep':
        
        for var in [compute, criteria]:
            if not var.is_defined():
                var.settle_to_default()
        
        sp_req_compute = {'pJSA', 'pJSI', 'pJSAnp'}
        
        # check to make sure that all of the data to be plotted is computed
        if (save_sweep_plots & sp_req_compute) - set(compute.value):
    
            print(('Some parameters marked for plotting are not present in the'
                   ' \'compute\' entry of the save dictionary. I will correct' 
                   ' it so that all your intended plotted data is calculated. '
                   'If you intend differently, use Ctrl+C to stop this and '
                   'fix it.\n'))
    
            compute.value = (save_sweep_plots & sp_req_compute)

        # everything that is computed is saved
        save_these = list({'poling_period', 'slope', 'opt_par'} | set(compute.value))
 
    communicate_simulation_type(simtype, signal_mode, 
                                [npts_i, npts_j, opt_npoints], 
                                opt_par_name, par_mode)
    
    # starting the simulation, get current date and time
    start_stamp = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    opt_crits = criteria.value; ncrits = len(opt_crits)
    trials_data = np.zeros(nconfs*ncrits, dtype=utils.DTYPE_LIST)

    global_line_no = 0
    
    for c in list_with_configs:
        
        print(f'Starting configuration {c}')

        cur_conf = parse.parse_refr_inds_string(c)
        npstr, nsstr, nistr = cur_conf
        material.set_conf(cur_conf)
        
        # In case we are doing a sweep AND the signal wls are all equal to
        # idler wls AND the configuration has signal <> idler symmetry
        # THEN we can do only half of the points (ie w_s > w_i)
        # OR if we deliberately choose to say "Idler is X and Signal is Y"
        
        # simpl plot is basically whether we can skip a case where ws < wi
        # (almost always)
        # it suffices that we are not in a sweep of a nondegen configuration
        simpl_plot = (not (sweep_sq_wdw and (nsstr != nistr))) and (signal_mode != 'match')
        
        # print(f'SAVE THESE: {save_these}')
        
        full_data = run_one_trial(material, pump_wl, idler_wls, signal_wls,
                                  [npts_i, npts_j, ncrits],
                                  signal_mode=signal_mode,
                                  sig_eq_idl=sig_eq_idl,
                                  opt_par=opt_par.value,
                                  opt_other_par=opt_other_par,
                                  opt_npoints=opt_npoints,
                                  opt_crits=opt_crits,
                                  opt_linear=optimization.get('linear'),
                                  opt_values=opt_values,
                                  prelim_sweep=prelim_sweep,
                                  rev_skcond=reverse_skip_cond,
                                  simpl_plot=simpl_plot,
                                  compute_these=compute.value,
                                  save_folder=folder_name,
                                  save_prefix=save_prefix,
                                  save_these_txts=save_these,
                                  save_opt_logs=save_opt_logs,
                                  fdata=filtering,
                                  **kwargs)
        
        nlines = len(full_data)
        
        if not prelim_sweep:
            
            for i_conf in range(nlines//ncrits):
                for k in range(ncrits):
                    # makes the data from first criterium first, 
                    # then from second criterium etc etc
                    trials_data[global_line_no + k*nconfs] =  tuple(full_data[i_conf*ncrits + k])
    
                global_line_no += 1

        # trials_data[global_line_no] = configuration, wl_s, wl_i, pper, A, B, slope, *pgdata, L, wl_p_std
        # plot the highest value of purity for the first criterium
    
    
    # ending the simulation, get current date and time
    end_stamp = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    

    # Find the configuration for which the purity is closer to 1
    # ind = np.argmin(np.abs(trials_data['purities']-1.))

    # should sort the array at chunks of nconfs at a time
    # in total ncrits times

    srt_data = trials_data.copy()
    
    
    for k in range(ncrits):
        
        cur_crit = opt_crits[k]

        # make it into list to not change the original array
        cur_sort_data = np.array(list(trials_data[cur_crit]))

        # conserve only this part of the cur_sort_data
        conserve = list(cur_sort_data[k*nconfs:(k+1)*nconfs])
        
        # fill the sorting data with a number way higher than all purities
        cur_sort_data[:] = 30.

        # refill the cur_sort_data in the part of interest
        cur_sort_data[k*nconfs:(k+1)*nconfs] = conserve

        # by this time we have an array that in the current criterium
        # region is equal to the original data and is 30 elsewhere

        srt_data = srt_data[cur_sort_data.argsort(kind='mergesort')]

    srt_data = srt_data[::-1]
    
    # data is at this point sorted in chunks of length nconfs, where
    # in each chunk the applied criteria for sorting is changing,
    # and the parameter (purity) is decreasing

    optpar = opt_par.value if simtype == 'optimization' else 'NO'
    
    wl_p_str = 'given by energy conservation' if pump_wl == 'match' else f'{pump_wl}'
    compl_info = ' with signals equal to idlers' if sig_eq_idl else ''
    signal_mode_str = f'{signal_mode}{compl_info}'
    
    
    utils.save_struct_array(srt_data, folder_name, file_name, wl_p_str, 
                            material,
                            crit_list=opt_crits,
                            configurations=string_with_configs,
                            signal_mode_str=signal_mode_str,
                            optpar=optpar,
                            npts=[npts_j, npts_i, opt_npoints],
                            start_end=[start_stamp, end_stamp])
    
    
    if save_final_plots:
        plaid.make_joint_spectral_plots(folder_name,
                                        save_final_plots,
                                        show_lines=show_lines,
                                        save_prefix=save_prefix,
                                        **kwargs)
        
        
    if save_sweep_plots:
        plaid.make_sweep_plots(folder_name, ' '.join(list(save_sweep_plots)),
                               save_prefix=save_prefix)


    return





def run_one_trial(material, pump_wl, idler_wls, signal_wls,
                  array_dims,
                  signal_mode='',
                  sig_eq_idl='',
                  opt_par='',
                  opt_other_par=0,
                  opt_npoints=0,
                  opt_crits=[],
                  opt_linear=True,
                  opt_values=False,
                  opt_gamma_lims=False,
                  opt_override_slope_crit=us.OVERRIDE_SLOPE_CRITERIUM,
                  prelim_sweep=False,
                  rev_skcond=False,
                  simpl_plot=False,
                  save_folder='',
                  save_prefix='',
                  save_these_txts=[],
                  save_opt_logs=False,
                  compute_these=[],
                  fdata={},
                  **kwargs):
    
    """
    Run signal and idler sweep with fixed material.
    
    Keeping constant the material, temperature, crystal orientation, and pump
    wavelength, find the best crystal length / pump FWHM for purity maximiza-
    tion.
    
    Parameters
    ----------
    
    material : bishop.materials.Material
        The simulated material, containing the refractive indices, the tempera-
        ture, and the configuration.
    
    pump_wl : float or \'match\'
        If float, specifies the pump wavelength (in um). If \'match\',
        then the pump wavelength will be the harmonic mean of the signal and 
        idler wavelengths (given by energy conservation)
    
    idler_wls : float or list/tuple/np.ndarray
        Test values for the idler wavelengths (unit: `um`).
        
    signal_wls : float or list/tuple/np.ndarray
        Test values for the signal wavelengths (unit: `um`).
        
    array_dims : list
        Dimensions of the array of optimization results: (number of signal 
        points, number of idler points, number of criteria). If a `match` type
        simulations is to be done, then the number of signal points has to be 1.
        
    signal_mode : `sweep` or `match`
        The mode of operation of the simulations. See documentation for more
        information.    
    
    """
    
    config = material.conf
    
    npts_i, npts_j, n_crits = array_dims
    
    filter_data = (fdata != {})
    
    # is the optimization ggoing to be by making a linear range
    # of the optimizing parameter or a linear range of gammas?
    # TODO: Implement this

    window_lims = kwargs.get('window limits')

    if window_lims:
        # window_lims are given in wavelength, need to convert to angfreq
        window_lims = bop.wl2w(np.array(window_lims))
    
    if save_prefix != '':
        save_prefix += '_'
    
    # separate maximization means that all of the quantities in 
    # compute_these will be maximized separately
    # TODO: implement this
    sep_max = False
    #sep_max = optimization.get('separate maximization', False)
    
    if not prelim_sweep:
        if opt_par == 'crystal_length' or not opt_par:
            p_fwhm_val, p_std_unit = opt_other_par.split()
            p_fwhm_val = float(p_fwhm_val)
            crystal_length = opt_values
        elif opt_par == 'pump_FWHM':
            crystal_length = opt_other_par
            

    char = '_' if ('_' in config) else ''
    npstr, nsstr, nistr = config.split('_') if ('_' in config) else config
    
    
    cp_purJSI = 'pJSI' in compute_these
    cp_purJSA = 'pJSA' in compute_these
    cp_purJSAnp = 'pJSAnp' in compute_these
    cp_visib = 'visibility' in compute_these
    cp_opdist = 'operational_distance' in compute_these
    cp_eta = 'overlap' in compute_these
    
    if cp_visib:
        cp_purJSA = True

    ##################### COMPUTE INITIAL QUANTITIES ##########################
    
    # Work in angular frequency, not in wavelength!
    idler_wls = bop.wl2w(idler_wls)
    signal_wls = bop.wl2w(signal_wls)
    
    
    ###########################################################################
    
    pol_pers = np.zeros(array_dims[:2])
    par_optimized = np.zeros(array_dims)
    
    As = np.zeros(array_dims[:2])
    Bs = np.zeros(array_dims[:2])
    
    pump_wl_widths = np.zeros(array_dims[:2])
    
    # this mask is to not calculate the pairs of wavelengths where
    # wavelength(signal) > wavelength(idler)
    wls_mask = np.zeros(array_dims, dtype=bool)

    purs_JSA = np.zeros(array_dims)
    purs_JSI = np.zeros(array_dims)
    purs_JSAnp = np.zeros(array_dims)

    flags_circular_shape = np.zeros(array_dims)
    sigma_ratios = np.zeros(array_dims)
    opt_gammas_JSI = np.zeros(array_dims)
    opt_gammas_JSA = np.zeros(array_dims)
    opt_gammas_JSAnp = np.zeros(array_dims)
    visibs = np.zeros(array_dims)
    opdists = np.zeros(array_dims)
    etas = np.zeros(array_dims)
    
    for i, w_i in enumerate(idler_wls):
        
        print(f'Doing idler #{i:d}')
        
        for j in range(npts_j):

            if (signal_mode == 'sweep'):
                # cross every w_i with every w_s, so use variable j
                w_s = signal_wls[j]

            elif (signal_mode == 'match'):
                # just match each term in signal_wls and idler_wls 
                w_s = signal_wls[i]
            
            if ((not rev_skcond and w_s < w_i) or (rev_skcond and w_i < w_s)) and simpl_plot:

                wls_mask[i, j] = True
                
                # simp_plot = (signal_mode == 'sweep' and sig_eq_idl and nsstr == nistr)
                
                # In case:
                # we are doing a sweep AND the signal wls are all
                # equal to idler wls AND the configuration has signal <> 
                # idler symmetry, 
                # OR 
                # we are in a sweep AND not in sig_eq_idl mode AND w_s < w_i
                # THEN we can do only half of the points (ie w_s > w_i)
                continue
            
            if w_s + w_i < bop.wl2w(0.610) or w_s + w_i > bop.w2wl(0.520):
                wls_mask[i, j] = True
                continue
            
            w_p = w_s + w_i if (pump_wl == 'match') else bop.wl2w(pump_wl)

            # n_sh = n_pump(pump_wl)             # refr index at pump wavelength
            # avg_chisq = chi2(material, 'xxz')  # average chi2 in given direction

            
            material.pper = None
            delta_k = material.dk(w_p, w_s, w_i, mode='angfreq')
            pol_per = 2*us.PI/delta_k
            pol_pers[i, j] = pol_per
            
            material.set_pper(pol_per)

            A, B = material.A_and_B(w_p, w_s, w_i, mode='angfreq')
            slope = -A/B
            
            
            As[i, j] = A
            Bs[i, j] = B

            if (not opt_override_slope_crit) and (slope < 0):
                # no L optimization, we can proceed to next signal
                continue
            
            if isinstance(opt_values, np.ndarray):
                opt_npoints = len(opt_values)
            
            if 1: #np.abs(slope-1) < .1:
                
                opt_run_results = { 'pJSI': opt_npoints*[0.],
                                    'pJSA': opt_npoints*[0.],
                                    'pJSAnp': opt_npoints*[0.],
                                    'visibility': opt_npoints*[0.],
                                    'optdist': opt_npoints*[0.] }
                
                pur_opt_JSI = opt_npoints*[0.]
                pur_opt_JSA = opt_npoints*[0.]
                pur_opt_JSAnp = opt_npoints*[0.]
                visibs_opt = opt_npoints*[0.]
                opdists_opt = opt_npoints*[0.]

                flags_sub = opt_npoints*[0.]
                sigma_ratios_sub = opt_npoints*[0.]

                etas_opt = opt_npoints*[0.]
                
                
                if prelim_sweep:
                    opt_npoints = 0
                else:
                    if (not opt_par or opt_par == 'crystal_length'):
                        
                        if p_std_unit == 'um':
                            w_p_std = bop.wl2w_std(bop.w2wl(w_p), 
                                                   bop.pw2ps(p_fwhm_val))
                            
                        elif p_std_unit == 's':
                            w_p_std = bop.pw2ps(bop.dt2dw(p_fwhm_val,
                                                          tbp=us.GLOBAL_TBP))
                            
                        opt_other_par = w_p_std
                        wl_p_std = bop.w2wl_std(w_p, w_p_std)
                        pump_wl_widths[i, j] = wl_p_std
                    
                
                test_gammas, test_pars = base.get_test_pars(opt_values, 
                                                            opt_npoints, opt_gamma_lims, 
                                                            opt_crits, opt_other_par,
                                                            opt_linear, A, B)
                
                
                for opt_i in range(opt_npoints):

                    nj = 1
                    
                    # if no optimization is intended, crystal_length and w_p_std
                    # have already been defined above, so no need to change    
                    if opt_par == 'crystal_length':
                        crystal_length = test_pars[opt_i]
                        material.set_length(crystal_length)
                    elif opt_par == 'pump_FWHM':
                        w_p_std = bop.pw2ps(test_pars[opt_i])
                    
                    data_jsi = base.get_JSFs(w_p, w_p_std, w_s, w_i,
                                             material,
                                             output='all',
                                             split_pm=True,
                                             npts=us.OPT_LOOP_NPOINTS,
                                             resolution=us.OPT_LOOP_RESOLUTION,
                                             lims=window_lims)
                    

                    if filter_data:
                        # get also the overlap integral oi
                        [plot_s, plot_i, pe, pm_sep, pm_app_sep, oi] = data_jsi
                    else:
                        # no filtering, no overlap integral
                        [plot_s, plot_i, pe, pm_sep, pm_app_sep] = data_jsi
                        oi = 1.
                    
                    pm = pm_sep[0] * pm_sep[1]
                    pm_app = pm_app_sep[0] * pm_app_sep[1]

                    JSI = np.abs(pe)**2 * np.abs(pm)**2
                    JSA = pe*pm
                    
                    # JSAnp = np.abs(JSA)
                    JSAnp = pm_sep[0] * pe
                    # JSA_app_noph = pm_app_sep[0]
                    
                    # npts is the number of points used in the matrix F to describe
                    # the JSI function: F is an (npts, npts) matrix
                    
                    #plt.pcolormesh(plot_s, plot_i, np.abs(JSA)**2)
                    #plt.show()
                    
                    
                    if cp_purJSI:
                        
                        pur_opt_JSI[opt_i] = 1/get_K_eig_numba(utils.normal(JSI, nj))

                        sigma_x, sigma_y = utils.estimate_sigma(JSI,
                                                                running_window=0)

                        tol = 0.3

                        if sigma_y != 0.:
                            flags_sub[opt_i] = (abs(sigma_x/sigma_y-1) <= tol)
                            sigma_ratios_sub[opt_i] = (sigma_x/sigma_y)
                        else:
                            flags_sub[opt_i] = False
                            sigma_ratios_sub[opt_i] = 0


                    if cp_purJSA:
                        pur_opt_JSA[opt_i] = 1/get_K_eig_numba(utils.normal(JSA, nj))
                    
                    if cp_purJSAnp:
                        pur_opt_JSAnp[opt_i] = 1/get_K_eig_numba(utils.normal(JSAnp, nj))

                    if cp_visib or cp_opdist:

                        F = JSA[::nj, ::nj].astype(np.complex128)
                        F_H = np.conjugate(np.transpose(F)).astype(np.complex128)

                        opdist_mtx = dot_py(F, F_H) - dot_py(F_H, F)
                        
                        opdist_value = 1/get_K_eig_numba(utils.normal(opdist_mtx, nj))
                        

                        if cp_visib:
                            visibs_opt[opt_i] = pur_opt_JSA[opt_i] - 0.5*opdist_value
                        
                        if cp_opdist:
                            opdists_opt[opt_i] = opdist_value

                    if cp_eta:
                        etas_opt[opt_i] = oi
                    
                    """
                    if cp_genrate:
                        
                        data = [ n_pump, n_signal, n_idler, 
                                 wp, sp, ws0, wi0, S_p, crystal_length ]
                        
                        lib = grate.load_library(PATH_TO_LIBRARY)
                        ptr = grate.generate_pointer(ws0, wi0, A, B, sp, pper, L)
                        Kappa = grate.calculate_Kappa(ptr, data, lib)
                        
                        alpha_sq = TARGET_BETA_SQ * n_sh**6 * 8*pi*eps0 / avg_chisq**2 / Kappa
                        
                        E_pulse = alpha_sq * epsilon    # energy of one pump pulse  [J]
                        
                        req_Ppk[i, j, k, kk] = E_pulse / np.sqrt(pi * dt_std**2)

                     """
                     
                
                if (opt_npoints > 0):

                    if save_opt_logs:
                            
                        array_stack = np.vstack((test_pars, pur_opt_JSA, pur_opt_JSI))    
                        wl_s, wl_i = bop.w2wl([w_s, w_i])
                        np.savetxt(f'{save_folder}/{wl_s:f}_{wl_i:f}_{save_prefix}{config}_opt_sweep.txt', 
                                                                        array_stack)
                        
                    # purities array is filled with the closest purity
                    for k in range(n_crits):
                        
                        cur_crit = opt_crits[k]
                        
                        cur_list = opt_run_results[cur_crit]
                        
                        if cur_crit == 'pJSI':
                            pur_argmax = utils.find_index_of_nearest(pur_opt_JSI, 1.)
                        elif cur_crit == 'pJSA':
                            pur_argmax = utils.find_index_of_nearest(pur_opt_JSA, 1.)
                        elif cur_crit == 'pJSAnp':
                            pur_argmax = utils.find_index_of_nearest(pur_opt_JSAnp, 1.)
                        elif cur_crit == 'visibility':
                            pur_argmax = utils.find_index_of_nearest(visibs_opt, 1.)


                        if (sep_max and (n_crits == 1)):

                            argm_JSI = utils.find_index_of_nearest(pur_opt_JSI, 1.)
                            argm_JSA = utils.find_index_of_nearest(pur_opt_JSA, 1.)
                            argm_JSAnp = utils.find_index_of_nearest(pur_opt_JSAnp, 1.)
                            purs_JSI[i, j, k] = pur_opt_JSI[argm_JSI]
                            purs_JSA[i, j, k] = pur_opt_JSA[argm_JSA]
                            purs_JSAnp[i, j, k] = pur_opt_JSAnp[argm_JSAnp]

                        else:
                            purs_JSI[i, j, k] = pur_opt_JSI[pur_argmax]
                            purs_JSA[i, j, k] = pur_opt_JSA[pur_argmax]
                            purs_JSAnp[i, j, k] = pur_opt_JSAnp[pur_argmax]
                            
                            # print(bop.w2wl([w_s, w_i]), pur_opt_JSA, pur_opt_JSA[pur_argmax])

                        etas[i, j, k] = etas_opt[pur_argmax]

                        visibs[i, j, k] = visibs_opt[pur_argmax]
                        opdists[i, j, k] = opdists_opt[pur_argmax]

                        sigma_ratios[i, j, k] = sigma_ratios_sub[pur_argmax] 
                        flags_circular_shape[i, j, k] = flags_sub[pur_argmax]
                        
                        opt_gammas_JSI[i, j, k] = test_gammas[pur_argmax]
                        opt_gammas_JSA[i, j, k] = test_gammas[pur_argmax]
                        opt_gammas_JSAnp[i, j, k] = test_gammas[pur_argmax]

                        par_optimized[i, j, k] = test_pars[pur_argmax]

    Bs = np.ma.masked_array(Bs, mask=(Bs==0.))
    slopes = -As/Bs
    
    # mask the slopes that are smaller than 0 or larger than 5

    #mask_slopes = ((slopes > 50) | (slopes < -50))
    #mask_slopes = np.zeros_like(slopes, dtype=bool)

    mg_signals, mg_idlers = np.meshgrid(signal_wls, idler_wls)


    arr_names = {'pJSI': purs_JSI, 
                 'pJSA': purs_JSA,
                 'pJSAnp': purs_JSAnp,
                 'JSI_gamma': opt_gammas_JSI,
                 'JSA_gamma': opt_gammas_JSA,
                 'abs(JSA)_gamma': opt_gammas_JSAnp,
                 'visibility': visibs,
                 'operational_distance': opdists, 
                 'slope': slopes,
                 'poling_period': pol_pers,
                 'JSI_asym': sigma_ratios, 
                 'opt_par': par_optimized,
                 'overlap': etas }
    
    for name in save_these_txts:
        
        utils.my_savetxt(f'{save_folder}/{save_prefix}{config}_{name}.txt',
                         arr_names[name])
    
    
    utils.my_savetxt(f'{save_folder}/{save_prefix}pump_bands.txt', pump_wl_widths)
    utils.my_savetxt(f'{save_folder}/{save_prefix}signal_wls.txt', bop.w2wl(mg_signals))
    utils.my_savetxt(f'{save_folder}/{save_prefix}idler_wls.txt', bop.w2wl(mg_idlers))

    ret_list = []

    masks = [wls_mask, ~wls_mask]
    
    # cases:
    # 1. we are in simplified plotting
    # 2. we are in full plotting but the plot corresponds to two configs
    # 3. we are in full plotting but the plot corresponds to one config
    if signal_mode == 'sweep' and sig_eq_idl and nsstr != nistr:
        # only activated in one case, where in a sweep we are in a nondegen
        # configuration (only case where we saved time by filling the array
        # from the start)
        swap_config = f'{npstr}{char}{nistr}{char}{nsstr}'
        string_configs = [ config, swap_config ]
    else:
        string_configs = [ config ]
    
    for configuration_index in range(len(string_configs)):
        # for each trial 2 configurations are done
        # given that ijk (ws, wi) = ikj (wi, ws)

        cur_mask = masks[configuration_index]

        for k in range(n_crits):
            
            cur_crit = opt_crits[k]

            if cur_crit == 'pJSI':
                purities = purs_JSI[:, :, k]
            elif cur_crit == 'pJSA':
                purities = purs_JSA[:, :, k]
            elif cur_crit == 'abs(JSA)_purity':
                purities = purs_JSAnp[:, :, k]

            purities = np.ma.masked_array(purities, mask=cur_mask[:, :, k])

            # find where the purity is closer to one    
            index_i, index_j = utils.find_index_of_nearest(purities, 1)

            # already in um since units of PMF are units of k ie [um^-1]
            best_pper = pol_pers[index_i, index_j]

            best_A = As[index_i, index_j]
            best_B = Bs[index_i, index_j]

            best_slope = -best_A/best_B

            bp_JSI = purs_JSI[index_i, index_j, k] if cp_purJSI else 0.
            bp_JSA = purs_JSA[index_i, index_j, k] if cp_purJSA else 0.
            bp_JSAnp = purs_JSAnp[index_i, index_j, k] if cp_purJSAnp else 0.

            bg_JSI = opt_gammas_JSI[index_i, index_j, k] if cp_purJSI else 0.
            bg_JSA = opt_gammas_JSA[index_i, index_j, k] if cp_purJSA else 0.
            bg_JSAnp = opt_gammas_JSAnp[index_i, index_j, k] if cp_purJSAnp else 0.
            
            best_visib = visibs[index_i, index_j, k] if cp_visib else 0.

            best_oi = etas[index_i, index_j, k] if cp_eta else 0.

            w_i = idler_wls[index_i]
            opt_wli = bop.w2wl(w_i)

            if (signal_mode == 'sweep'):
                opt_wls = bop.w2wl(signal_wls[index_j])
            else:
                opt_wls = bop.w2wl(signal_wls[index_i])
            
            
            if opt_par == 'crystal_length':
                crystal_length = par_optimized[index_i, index_j, k]
                wl_p_std = pump_wl_widths[index_i, index_j]
            elif opt_par == 'pump_FWHM':
                wl_p_std = bop.w2wl_std(bop.wl2w(utils.hmean(opt_wls, opt_wli)),
                                         par_optimized[index_i, index_j, k])


            
            pgdata = [ bp_JSI, bg_JSI, 
                       bp_JSA, bg_JSA, 
                       bp_JSAnp, bg_JSAnp, 
                       best_visib, best_oi ]
            
            ret_list.append([string_configs[configuration_index], 
                             opt_wls, opt_wli, 
                             best_pper, best_A, best_B, 
                             best_slope, *pgdata,
                             crystal_length,  bop.pw2ps(wl_p_std, rev=True)])
    
    
    return ret_list




