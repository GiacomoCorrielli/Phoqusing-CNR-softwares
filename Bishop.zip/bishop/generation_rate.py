import ctypes
import numpy as np

from scipy import integrate, LowLevelCallable

import bishop.settings as us
import bishop.utilities as utils
import bishop.base_functions as base
import bishop.parsing_functions as pf




def load_library(conf, mat):
    """Return the library to be used.
    
    Libraries are placed in the bishop direc-
    tory, inside the data/libraries folder, and are identified by the material
    and the configuration to be used. Read the manual to understand how to add
    a custom material and respective configurations.
    
    Parameters
    ----------
    conf : str
        Configuration (polarizations of the pump, signal and idler), given in 
        the form '???' where each of the ? can be x, y or z.
    
    mat : str
        Material of the nonlinear crystal.
    
    Returns
    -------
        A ctypes.CDLL library for the material and configuration given.
    
    """
    lib = ctypes.CDLL(utils.PATH_TO_LIBRARY(conf, mat))
    
    lib.integrand.restype = ctypes.c_double
    lib.integrand.argtypes = (ctypes.c_int, 
                              ctypes.POINTER(ctypes.c_double), 
                              ctypes.c_void_p)
    
    return lib


def calculate_Kappa(data, 
                    taylor=us.INT_KAPPA_TAYLOR,
                    mode=us.INT_KAPPA_MODE,
                    gauss_aprox=False):
    
    
    """ 
    Wrapper for the calculation of K in PR-A 77, 033808 (2008).
    
    There is a slight change between the definition used here and the one in
    the paper, but essentially the value of K remains the same.
    
    .. math::
        
        K = \int_{0}^{\infty} \int_{0}^{\infty}  \hbar(\omega_{s} + \omega_{i})  \kappa'_{p}(\omega_s + \omega_i) \omega_{s} \kappa'_{s} ( \omega_{s} ) 
             \omega_{i} \kappa'_{i}(\omega_{i}) 
            J(\omega_{s}, \omega_{i}) d \omega_{s} d \omega_{i} ,
        
    where J is essentially proportion to the integral of the JSI divided by wavevector-independent beam area A,
    
    .. math::
        
        J (\omega_s, \omega_i) = \\frac{N}{A} | \\textrm{JSI}(\omega_s, \omega_i) |^2.
        
    
    data (list)
        Contains the ordered data: ws0, wi0, A, B, sp, pper, L, temperature, 
        taylor, mode.
    
            
    taylor (bool)
        When set to True, uses the Taylor expansion, up to first order, of
        :math:`\delta k`, which is :math:`A (\omega_s-\omega_s^0) + B ( \omega_i - \omega_i^0 )`,
        where A and B are related to the derivatives of pump, signal, and idler
        wavevectors with respect to their respective central angular frequencies
        (for more on this, read the manual).
        
        
    mode (number)
        When equal to 0, the integration includes the product of the wavevector 
        derivatives and that of the angular frequencies.
        When equal to 1, the integration includes only the product of the angu-
        lar frequencies, treating the wavevector derivatives as constant and 
        equal to their value at the central signal, idler, and pump frequen-
        cies.
        When equal to 2, the integration includes neither the product of angu-
        lar velocities, nor that of wavevector derivatives. These quantities 
        are assumed to be constant, and equal to their respective values for
        the central signal, idler, and pump frequencies.
        
    Returns
    -------
        The calculated Kappa, according to the calculation preferences selected.
        
    """
    
    wp, sp, ws0, wi0, S_p, mat = data
    
    conf = mat.conf
    T = mat.T
    L = mat.L
    mat_name = mat.name
    pper = mat.pper
    
    A, B = mat.A_and_B(wp, ws0, wi0, mode='angfreq')
    
    # mm = mat.dk(wp, ws0, wi0, mode='angfreq') 
    
    # pper = 2*us.PI / mm
    print(pper, L, conf)
    ptr = generate_pointer(ws0, wi0, A, B, sp, pper, L, T, taylor, mode)
                        
    lib = load_library(conf, mat_name)
    
    user_data = ctypes.cast(ptr, ctypes.c_void_p)
    
    llc = LowLevelCallable(lib.integrand, user_data)
    integral, _ = integrate.nquad(llc, 
                                  [[-us.INT_KAPPA_LIM, us.INT_KAPPA_LIM], 
                                   [-us.INT_KAPPA_LIM, us.INT_KAPPA_LIM]],
                                  opts=[us.INT_KAPPA_OPTS, us.INT_KAPPA_OPTS])
    
    
    # integral_nn is the integral from ws,i-lim*sigma to ws,i+lim*sigma
    # of the PEF^2 times the PMF^2, where the PEF is NOT normalized, still 
    # sp^2 is needed because of the differentials 
    integral_nn = integral * sp**2
    integral_nn_ga = us.PI*sp/L/np.sqrt(us.GA_GAMMA)/np.abs(B-A)

    
    
    # sp**2 comes from the adimensionalization done when integrating
    # (us.PI*sp**2)**(-1/4) is the PEF prefactor for normalization of the |PEF|^2
    #   (when squaring it becomes (us.PI*sp**2)**(-1/2))
    integral *= sp**2 * (us.PI*sp**2)**(-1/2)
    
    
    dkp_dw = 1e6 * mat.kprime(conf[0], wp)    
    dks_dw = 1e6 * mat.kprime(conf[1], ws0)
    dki_dw = 1e6 * mat.kprime(conf[2], wi0)
    
    
    if mode == 0:
        Kappa = 1e3**3 * us.HBAR / S_p * (1e-6*L)**2 * integral
    elif mode == 1:
        Kappa = 1e12**3 * dkp_dw * dks_dw * dki_dw * us.HBAR / S_p * integral * (1e-6*L)**2
    elif mode == 2:
        Kappa = dkp_dw*dks_dw*dki_dw * (us.HBAR*ws0*wi0*(ws0 + wi0)) / S_p * integral * (1e-6*L)**2
    
    
    return Kappa
        


def generate_pointer(ws0, wi0, A, B, sp, pper, L, T,
                     taylor=us.INT_KAPPA_TAYLOR,
                     mode=us.INT_KAPPA_MODE):
    
    """
    Create a pointer with all the data needed for the integration. 
    
    Parameters
    ----------
    ws0, wi0 : floats (unit: rad/s)
        Central signal and idler angular frequencies.
    
    A, B : floats (unit: um^-1 / rad/s)
        Defined as :math:`A = k'_p (\omega_p + \omega_s) - k'_s(\omega_s))` and
        `B = k'_p (\omega_p + \omega_s) - k'_i(\omega_i))`.
    
    sp : float (unit: rad/s)
        Pump amplitude standard deviation in the angular frequency domain.
        
    pper : float (unit: um)
        Poling period, can be given in order to expedite the calculation within
        the C functions, otherwise it will be calculated for every call of the 
        integrand, thus slowing the code. 
    
    L : float (unit: um)
        Crystal length.
    
    T : float (unit: ºC)
        Temperature of the crystal.
    
    taylor : bool
        Whether to use or not Taylor expansion of the phase matching function
        argument (more on this in the integrand function docstring).
    
    mode : int
        When equal to 0, the integration includes the product of the wavevector 
        derivatives and that of the angular frequencies.
        When equal to 1, the integration includes only the product of the angu-
        lar frequencies, treating the wavevector derivatives as constant and 
        equal to their value at the central signal, idler, and pump frequen-
        cies.
        When equal to 2, the integration includes neither the product of angu-
        lar velocities, nor that of wavevector derivatives. These quantities 
        are assumed to be constant, and equal to their respective values for
        the central signal, idler, and pump frequencies.
        (more on this in the integrand function docstring)
        
    """
    
    pper_ct = ctypes.c_double(pper*1e-3)   # (mm)
    ws0_ct_rs = ctypes.c_double(ws0*1e-12) # (Trad/s)
    wi0_ct_rs = ctypes.c_double(wi0*1e-12) # (Trad/s)
    A_ct_rs = ctypes.c_double(A*1e12*1e3)  # ( mm-1 / Trad/s )
    B_ct_rs = ctypes.c_double(B*1e12*1e3)  # ( mm-1 / Trad/s )
    L_ct = ctypes.c_double(L*1e-3)         # (mm)
    T_ct = ctypes.c_double(T)              # (ºC)
    
    sp_ct_rs = ctypes.c_double(sp*1e-12)   # Trad/s
    
    taylor_ct = ctypes.c_double(taylor)
    mode_ct = ctypes.c_double(mode)

    ptr = (ctypes.c_double*10)(A_ct_rs, B_ct_rs, L_ct,
                               sp_ct_rs, ws0_ct_rs, wi0_ct_rs,
                               pper_ct, T_ct, taylor_ct, mode_ct)
    
    return ptr
    


def get_name(taylor, mode):
    
    if mode == 0.:
        text = 'Exact'
    elif mode == 1.:
        text = 'IntW'
    else:
        text = 'IntJSI'
    
    if taylor == 1.:
        text = 'T-' + text
    
    return text

    
    
    