#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  3 16:12:22 2022

@author: hjdno
"""

import numpy as np
import bishop.settings as us


###############################################################################
############################## OPTICS FUNCTIONS ###############################
###############################################################################

def k(refr_ind, wl):
    
    """
    Evaluates the wavenumber corresponding to a refractive index at given
    wavelength(s).

    Parameters
    ----------
    refr_ind : function
        Refractive index function, must accept wavelength in micrometers.
        
    wl : float or iterable (np.ndarray, list, tuple) (unit: um)
        The wavelength(s) where the refractive index is evaluated.
    
    Returns
    -------
    k(wl) : same type as wl (unit: um^-1)
        The corresponding wavenumber(s).
        
    """
    
    return refr_ind(wl)*2*us.PI/wl


def k_of_w(refr_ind, w):
    
    """
    Evaluates the wavenumber corresponding to a refractive index at a given
    angular frequency.

    Parameters
    ----------
    refr_ind : function
        Refractive index function, must accept wavelength in micrometers.
        
    w : float or iterable (np.ndarray, list, tuple) (unit: rad/s)
        The angular frequency where the refractive index is evaluated.
    
    Returns
    -------
    k(w) : same type as w (unit: m^-1)
        The corresponding wavenumber(s).
        
    """
    
    return refr_ind(2 * us.PI * us.C/w * 1e6 )*w/us.C

def pw2ps(fwhm_or_std, rev=False):
    
    """
    Converts pump intensity FWHM to pump field standard deviation, assuming
    a gaussian field, as default. Can also do the reverse conversion.

    Parameters
    ----------
    fwhm_or_std : float or iterable (np.ndarray, tuple, list) (unit: whatever)
        The FWHM in intensity or the standard deviation of the field. Can also
        be None, in which case the output is also None.

    rev: boolean
        Pass True in order to reverse the default way of conversion (which is 
        from FWHM to standard deviation).
    
    Returns
    -------
    std_or_fwhm : same type as fwhm_or_std
        Standard deviation (or FWHM) if the FWHM (or standard deviation) 
        was provided.
    """
    
    if fwhm_or_std is None:
        return None
    elif rev:
        return fwhm_or_std * 2.355 / np.sqrt(2)
    else:
        return fwhm_or_std * np.sqrt(2) / 2.355
    
def w2wl(omega):
    
    """
    Converts an angular frequency into a wavelength.

    Parameters
    ----------
    omega : float or iterable (np.ndarray, tuple, list) (unit: rad/s)
        Angular frequency(ies) to be converted.
        
         
    Returns
    -------
    output : same type as input (unit: um)
        The converted wavelength(s).
    """
    
    if isinstance(omega, list) or isinstance(omega, tuple):
        return [ w2wl(elem) for elem in omega ]
    
    else:
        return 2*us.PI*us.C/omega*1e6



def wl2w(wl):
    
    """
    Converts a wavelength into an angular frequency.

    Parameters
    ----------
    omega : float or iterable (np.ndarray, tuple, list) (unit: um)
        Wavelength(s) to be converted.
        
         
    Returns
    -------
    output : same type as input (unit: rad/s)
        The converted angular frequency(ies).
    
    """
    
    if isinstance(wl, (list, tuple, np.ndarray)):
        return [2*us.PI*us.C/(elem/1e6) for elem in wl]
    
    return 2*us.PI*us.C/(wl/1e6)



def wl2w_std(wl0, wlstd):
    
    """
    Converts a wavelength interval around a given central wavelength into an
    angular frequency interval.

    Parameters
    ----------
    wl0 : float (unit: um)
        Central wavelength of the wavepacket.
    
    wlstd : float (unit: um)
        Spectral wavelength width of the wavepacket.
    
    Returns:
    ~~~~~~~~
    : float (unit: rad/s)
        Spectral angular frequency width of the wavepacket.
        
    """

    return 2*us.PI*us.C/wl0**2 * wlstd * 1e6



def w2wl_std(w0, wstd):
    
    """
    Converts an angular frequency interval around a given central angular
    frequency into a wavelength interval.

    Parameters
    ----------
    wl0 : float (unit: rad/s)
        Central angular frequency of the wavepacket.
    
    wlstd : float (unit: rad/s)
        Spectral angular frequency width of the wavepacket.
    
    Returns:
    ~~~~~~~~
    : float (unit: um)
        Spectral wavelength width of the wavepacket.
        
    """
    
    return 2*us.PI*us.C/w0**2 * wstd * 1e6



def dt2dwl(wl, dt, tbp=us.GLOBAL_TBP):
    
    """
    Converts a time pulse duration at a given wavelength into the corresponding
    wavelength interval.

    Parameters
    ----------
    wl : float or iterable (np.ndarray, tuple, list) (unit: um) 
        Central wavelength(s) of the wavepacket.
    
    dt : float or iterable (np.ndarray, tuple, list) (unit: s)
        Corresponding time duration(s) of the wavepacket.
        
    Returns:
    ~~~~~~~~
    : same type as both inputs (np.ndarray, tuple, list) (unit: um)
        Spectral wavelength width of the wavepacket.
    
    """
    
    return (wl*1e-6)**2 * tbp / (us.C * dt) * 1e6


def dt2dw(dt_or_dw, tbp=us.GLOBAL_TBP):
    
    """
    Converts a time pulse duration at a given angular frequency into the 
    corresponding wavelength interval and vice-versa.

    Parameters
    ----------
    dt_or_dw : float (unit: by default, s and rad/s)
        Pulse duration or spectral width of the impulse.
        ATTENTION: If no tbp is given, these need to be the FWHM in intensity 
        either in the time or in the ANGULAR frequency domain.
        
    tbp: float (unit: 1)
        Time bandwidth product. The default tbp is the delta_t * delta_nu 
        product in intensity.
        
    Returns
    -------
    dw_or_dt : float (unit: depends)
        The spectral width or pulse duration of the impulse (unit is the 
        input's reciprocal unit).        
    """
    
    return 2 * us.PI * tbp / dt_or_dw



def dt2dwl_func(wl):
    ret = lambda dt: (wl*1e-6)**2 / (us.C * dt) * 1e9
    return ret


def dwl2dt_func(wl):
    ret = lambda dwl: (wl*1e-6)**2 / (us.C * dwl*1e-9)
    return ret


def k_prime(n, omega, ftype='n', precision=us.K_PRIME_PRECISION):
    
    """
    Computes first derivative of wavevector wither using an approximation based
    on first order finite difference, or using the specific kprime dictionary
    that all Materials have.
    
    Parameters
    ----------
    omega (float)
        The angular frequency where the derivative is to be evaluated.
        
    ftype (str)
        The type of function that was given. Can be 'n' (meaning that the re-
        fractive index function was given) or 'kp', if the kprime function was
        given.
        

    """
    wl = w2wl(omega)
    
    # Unit: um^-1 / um = um^-2
    dk_dwl = (k(n, wl+precision)-k(n, wl-precision))/2/precision

    dwl_dw = -2*us.PI*us.C/omega**2*1e6  # Unit: um / (rad/s)
    #dwl_dw = 1
    dk_dw = dk_dwl*dwl_dw          # Unit: um^-1 / rad/s)

    return dk_dw

