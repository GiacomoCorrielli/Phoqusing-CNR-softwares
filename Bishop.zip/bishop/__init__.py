version = (1, 0, 0)
VERSION = "%d.%d.%d" % version

__author__ = "HdN hugo.jorgedanobrega@polimi.it"
__doc__ = """BISHOP: BIphoton State Heralding by Optimization of Purity, a simulator of JSIs and JSAs with purity maximization."""
__license__ = "MIT"
__keywords__ = ''

# Optional variables
__description__ = ''
__keywords__ = ''

