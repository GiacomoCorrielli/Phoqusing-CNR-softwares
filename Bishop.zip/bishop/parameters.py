#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from textwrap import dedent


class Parameter():
    
    def __init__(self, name, value, unit, cont_dict, typ,
                 availables=False, default=None, entry_name=None):
        
        self.name = name
        self.unit = unit
        self.entry_name = name if entry_name is None else entry_name
        self.cont_dict = cont_dict
        self.value = value
        self.default = default
        self.type = typ
        self.availables = availables
        
        self.check_type()
    
    def check_type(self):
        v = self.value
        t = self.type
        
        if (v is not None) and (not isinstance(v, t)):
            raise TypeError((f'Parameter \'{self.name}\' must be a '
                             f'{t}, got {type(v)} instead.'))
        
    def is_defined(self):
        return (self.value is not None)
    
    def settle_to_default(self):
        
        self.value = self.default

        if self.availables: 
            av_pars = (f"Available parameters are {self.availables}. "
                       f"Separate different parameters with a single " 
                       f"space.")
        else:
            av_pars = ""
        
        msg =  (f"Missing \'{self.name}\', using default value "
                f"{self.default}. If you wish differently use Ctrl+C "
                f"to stop this and create an entry called "
                f"\'{self.entry_name}\' in the optimization dictionary. " 
                f"{av_pars}\n")

        print(msg)
    
    def check_definition(self):
        
        msg = ( f"Missing {self.name}. Add an entry called " 
                f"'{self.entry_name}\' to the optimization dictionary " 
                f"(unit: {self.unit}).\n" )
                         
        if not self.is_defined():
            print(msg)
            exit