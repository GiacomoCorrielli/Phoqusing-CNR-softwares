#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
from pathlib import Path
from scipy.interpolate import PPoly
from bishop.materials import Material

from types import MethodType

cubic_splines = {}

for name in ['n', 'k', 'kp']:
    for ax in ['y', 'z']:
        coefs = np.genfromtxt(Path.cwd()/f'{name}{ax}_wgKTP_PPoly_coeffs.txt')
        bpts = np.genfromtxt(Path.cwd()/f'{name}{ax}_wgKTP_PPoly_bpoints.txt')
        cubic_splines[f'{name}{ax}'] = PPoly(coefs, bpts)        


class MaterialWithSplines(Material):
    
    def __init__(self, cubic_splines, **params):
        super().__init__(**params)
        
        self.cs = cubic_splines      
        self.set_refr_index(params['dirs'], [self.ny, self.nz])
        self.set_kprime(params['dirs'], [self.kyPrime, self.kzPrime])
        
        
    def ny(self, T):
        def ny_function(wl):
            return self.cs['ny'](wl)
        return ny_function
    
    def nz(self, T):
        def nz_function(wl):
            return self.cs['nz'](wl)
        return nz_function
    
    def kyPrime(self, T):
        def f(wl):
            return self.cs['kpy'](wl)
        return f
    
    def kzPrime(self, T):
        def f(wl):
            return self.cs['kpz'](wl)
        return f
    
params = {'name': 'wgKTP', 'kprimes': None, 'dirs': ['y', 'z'],
          'refr_inds': None, 'allowed_confs': ['zzz', 'zyy', 'yyz']}

wgKTP = MaterialWithSplines(cubic_splines, **params)

wgKTP.save()

import dill
from pathlib import Path

p = Path(__file__).parent /'pickles'

with open(p/'wgKTP.pkl', 'rb') as pk:
    mat = dill.load(pk)
    
print(type(mat))
        


