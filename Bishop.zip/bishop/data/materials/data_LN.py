#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import bishop.settings as us
from bishop.materials import Material


F = lambda T: (T-24.5)*(T+570.5)

def nx(T):
    
    # Edwards and Lawrence (1984)
    # A temperature-dependent dispersion equation for congruently grown lithium niobate
    
    def nx_function(wl):
        argmt = (4.9048 + (0.11775 + 2.2314e-8*F(T))/(wl**2 - (2.1802e-2 - \
                 2.9671e-8*F(T))**2) + 2.1429e-8*F(T) - 2.7153e-2*wl**2)
        return np.sqrt(argmt)

    return nx_function


def nz(T):

    # Jundt (1997)
    # Temperature-dependent Sellmeier equation for the index of refraction, ne, in congruent lithium niobate 
    
    def nz_function(wl):
        argmt = (5.35583 + (0.100473 + 3.862e-8*F(T))/(wl**2 - \
                (0.20692 - 8.9e-9*F(T))**2) + 4.629e-7*F(T) + \
                (100 + 2.657e-5*F(T))/(wl**2 - 128.806) - 1.5334e-2*wl**2)
        return np.sqrt(argmt)

    return nz_function


def kxPrime(T):
    def f(wl):
        return -5.e-7*(wl**2*((us.PI*(-0.054306*wl - (2*(0.11775 + 2.2314e-8*(-24.5 \
                + T)*(570.5 + T))*wl)/(-(0.021802 - 2.9671e-8*(-24.5 + T)*(570.5 + \
                T))**2 + wl**2)**2))/(wl*np.sqrt(4.9048 + 2.1429e-8*(-24.5 + \
                T)*(570.5 + T) - 0.027153*wl**2 + (0.11775 + 2.2314e-8*(-24.5 + \
                T)*(570.5 + T))/(-(0.021802 - 2.9671e-8*(-24.5 + T)*(570.5 + T))**2 + \
                wl**2))) - (2*us.PI*np.sqrt(4.9048 + 2.1429e-8*(-24.5 + T)*(570.5 + \
                T) - 0.027153*wl**2 + (0.11775 + 2.2314e-8*(-24.5 + T)*(570.5 + \
                T))/(-(0.021802 - 2.9671e-8*(-24.5 + T)*(570.5 + T))**2 + \
                wl**2)))/wl**2))/(us.C*us.PI)
    return f


def kzPrime(T):
    def f(wl):
        return -5.e-7*(wl**2*((us.PI*(-0.030668*wl - (2*(100 + 0.00002657*(-24.5 + \
                T)*(570.5 + T))*wl)/(-128.806 + wl**2)**2 - (2*(0.100473 + \
                3.862e-8*(-24.5 + T)*(570.5 + T))*wl)/(-(0.20692 - 8.9e-9*(-24.5 + \
                T)*(570.5 + T))**2 + wl**2)**2))/(wl*np.sqrt(5.35583 + \
                4.629e-7*(-24.5 + T)*(570.5 + T) - 0.015334*wl**2 + (100 + \
                0.00002657*(-24.5 + T)*(570.5 + T))/(-128.806 + wl**2) + (0.100473 + \
                3.862e-8*(-24.5 + T)*(570.5 + T))/(-(0.20692 - 8.9e-9*(-24.5 + \
                T)*(570.5 + T))**2 + wl**2))) - (2*us.PI*np.sqrt(5.35583 + \
                4.629e-7*(-24.5 + T)*(570.5 + T) - 0.015334*wl**2 + (100 + \
                0.00002657*(-24.5 + T)*(570.5 + T))/(-128.806 + wl**2) + (0.100473 + \
                3.862e-8*(-24.5 + T)*(570.5 + T))/(-(0.20692 - 8.9e-9*(-24.5 + \
                T)*(570.5 + T))**2 + wl**2)))/wl**2))/(us.C*us.PI)
    return f


LN = Material('LN', 'x y z'.split(), 
              [nx, nx, nz], [kxPrime, kxPrime, kzPrime],
              ['xxz', 'xxx', 'zxx', 'zzz'])

LN.save()





