#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  3 12:59:00 2022

@author: hjdno
"""
import numpy as np
import bishop.settings as us
from bishop.materials import Material

# based on Takaoka, Appl Optics, 2002
dndT_ppKTP = [lambda wl: 1e-5*(0.1717/wl**3 - 0.5353/wl**2 + 0.8416/wl + 0.1627), 
              lambda wl: 1e-5*(0.1997/wl**3 - 0.4063/wl**2 + 0.5154/wl + 0.5425),
              lambda wl: 1e-5*(0.9221/wl**3 - 2.9220/wl**2 + 3.6677/wl - 0.1897)]

# refractive indices at 20ºC based on Takaoka, Appl Optics, 2002
rinds_ppKTP = [lambda wl: np.sqrt(3.29100 + 0.04140/(wl**2 - 0.03978) + 9.35522/(wl**2 - 31.45571)),
               lambda wl: np.sqrt(3.45018 + 0.04341/(wl**2 - 0.04597) + 16.98825/(wl**2 - 39.43799)),
               lambda wl: np.sqrt(4.59423 + 0.06206/(wl**2 - 0.04763) + 110.80672/(wl**2 - 86.12171))]

n_list_ppKTP = [lambda T: lambda wl: rinds_ppKTP[0](wl) + (T-20)*dndT_ppKTP[0](wl),
                lambda T: lambda wl: rinds_ppKTP[1](wl) + (T-20)*dndT_ppKTP[1](wl),
                lambda T: lambda wl: rinds_ppKTP[2](wl) + (T-20)*dndT_ppKTP[2](wl)] 

# n_dict_ppKTP = {'x': lambda T: lambda wl: rinds_ppKTP[0](wl) + (T-20)*dndT_ppKTP[0](wl),
#                 'y': lambda T: lambda wl: rinds_ppKTP[1](wl) + (T-20)*dndT_ppKTP[1](wl),
#                 'z': lambda T: lambda wl: rinds_ppKTP[2](wl) + (T-20)*dndT_ppKTP[2](wl)}


def kxPrime(T):
    
    def f(wl):
        
        return -5.e-7*(wl**2*((2*us.PI*(((-20 + T)*(-0.5151/wl**4 + 1.0706/wl**3 - \
                0.8416/wl**2))/100000. + ((-18.71044*wl)/(-31.45571 + wl**2)**2 - \
                (0.0828*wl)/(-0.03978 + wl**2)**2)/(2.*np.sqrt(3.291 + \
                9.35522/(-31.45571 + wl**2) + 0.0414/(-0.03978 + wl**2)))))/wl - \
                (2*us.PI*(((-20 + T)*(0.1627 + 0.1717/wl**3 - 0.5353/wl**2 + \
                0.8416/wl))/100000. + np.sqrt(3.291 + 9.35522/(-31.45571 + wl**2) + \
                0.0414/(-0.03978 + wl**2))))/wl**2))/(us.C*us.PI)
                                              
    return f

    
def kyPrime(T):
    
    def f(wl):
        return -5.e-7*(wl**2*((2*us.PI*(((-20 + T)*(-0.5991/wl**4 + 0.8126/wl**3 - \
               0.5154/wl**2))/100000. + ((-33.9765*wl)/(-39.43799 + wl**2)**2 - \
               (0.08682*wl)/(-0.04597 + wl**2)**2)/(2.*np.sqrt(3.45018 + \
               16.98825/(-39.43799 + wl**2) + 0.04341/(-0.04597 + wl**2)))))/wl - \
               (2*us.PI*(((-20 + T)*(0.5425 + 0.1997/wl**3 - 0.4063/wl**2 + \
               0.5154/wl))/100000. + np.sqrt(3.45018 + 16.98825/(-39.43799 + wl**2) \
               + 0.04341/(-0.04597 + wl**2))))/wl**2))/(us.C*us.PI)
                                             
    return f
                              

def kzPrime(T):

    def f(wl):
        return -5.e-7*(wl**2*((2*us.PI*(((-20 + T)*(-2.7663/wl**4 + 5.844/wl**3 - \
               3.6677/wl**2))/100000. + ((-221.61344*wl)/(-86.12171 + wl**2)**2 - \
               (0.12412*wl)/(-0.04763 + wl**2)**2)/(2.*np.sqrt(4.59423 + \
               110.80672/(-86.12171 + wl**2) + 0.06206/(-0.04763 + wl**2)))))/wl - \
               (2*us.PI*(((-20 + T)*(-0.1897 + 0.9221/wl**3 - 2.922/wl**2 + \
               3.6677/wl))/100000. + np.sqrt(4.59423 + 110.80672/(-86.12171 + wl**2) \
               + 0.06206/(-0.04763 + wl**2))))/wl**2))/(us.C*us.PI)
    
    return f
                                   
                                   
def nx(T):

    def nx_function(wl):
        dndT = lambda wl: 1e-5*(0.1717/wl**3 - 0.5353/wl**2 + 0.8416/wl + 0.1627)
        argmt = 3.29100 + 0.04140/(wl**2 - 0.03978) + 9.35522/(wl**2 - 31.45571)
        ct_term = np.sqrt(argmt)
        var_term = (T-20)*dndT(wl)
        return ct_term + var_term

    return nx_function


def ny(T):

    def ny_function(wl):
        dndT = lambda wl: 1e-5*(0.1997/wl**3 - 0.4063/wl**2 + 0.5154/wl + 0.5425)
        argmt = 3.45018 + 0.04341/(wl**2 - 0.04597) + 16.98825/(wl**2 - 39.43799)
        ct_term = np.sqrt(argmt)
        var_term = (T-20)*dndT(wl)
        return ct_term + var_term

    return ny_function


def nz(T):

    def nz_function(wl):
        dndT = lambda wl: 1e-5*(0.9221/wl**3 - 2.9220/wl**2 + 3.6677/wl - 0.1897)
        argmt = 4.59423 + 0.06206/(wl**2 - 0.04763) + 110.80672/(wl**2 - 86.12171)
        ct_term = np.sqrt(argmt)
        var_term = (T-20)*dndT(wl)
        return ct_term + var_term
    
    return nz_function


ppKTP = Material('ppKTP', 'x y z'.split(), [nx, ny, nz], 
                 [kxPrime, kyPrime, kzPrime],
                 ['zzz', 'zyy', 'zxx', 'yyz', 'xxz'])

ppKTP.save()









