#include <math.h>
#include <complex.h>

#define c 2.99792458e8
#define c_mant 2.99792458
#define Pi 3.14159259
#define T 25

double sinc(const double x) {

    if (x==0)
        return 1;
    
    return (sin(x)/x);

}



double ky(const double wl) {

    // wl: wavelength [um]
    // returns value in mm-1

    double ret = 1e3*(2*Pi*sqrt(2.157 + (71402.9*pow(wl,2))/(-3.2128770025e6 + pow(wl,2)) \
                      + (0.922527*pow(wl,2))/(-0.04977137902499999 + pow(wl,2))))/wl;
    
    return( ret );

}


double kyPrime(const double wl) {
    
    // wl: wavelength [um]
    // returns value in um-1 / Prad/s (order of unity)
    
    double ret = (-5*pow(wl,2)*((Pi*((-142805.8*pow(wl,3))/pow(-3.2128770025e6 + \
                    pow(wl,2),2) + (142805.8*wl)/(-3.2128770025e6 + pow(wl,2)) - \
                    (1.845054*pow(wl,3))/pow(-0.04977137902499999 + pow(wl,2),2) + \
                    (1.845054*wl)/(-0.04977137902499999 + pow(wl,2))))/(wl*sqrt(2.157 + \
                    (71402.9*pow(wl,2))/(-3.2128770025e6 + pow(wl,2)) + \
                    (0.922527*pow(wl,2))/(-0.04977137902499999 + pow(wl,2)))) - \
                    (2*Pi*sqrt(2.157 + (71402.9*pow(wl,2))/(-3.2128770025e6 + pow(wl,2)) \
                    + (0.922527*pow(wl,2))/(-0.04977137902499999 + \
                    pow(wl,2))))/pow(wl,2)))/(c_mant*Pi);
                
    return( ret );   
}

                                                              
                                                              
double kz(const double wl) {
        
    // wl: wavelength [um]
    // returns value in mm-1

    double ret = 1e3*(2*Pi*sqrt(2.12441 + (80568.4*pow(wl,2))/(-3.1032697920999997e6 + \
                      pow(wl,2)) + (1.22537*pow(wl,2))/(-0.053477487504000006 + \
                      pow(wl,2))))/wl;

}
                                                    

double kzPrime(const double wl) {
    
    // wl: wavelength [um]
    // returns value in um-1 / Prad/s (order of unity)
    
    double ret = (-5*pow(wl,2)*((Pi*((-161136.8*pow(wl,3))/pow(-3.1032697920999997e6 \
                    + pow(wl,2),2) + (161136.8*wl)/(-3.1032697920999997e6 + pow(wl,2)) - \
                    (2.45074*pow(wl,3))/pow(-0.053477487504000006 + pow(wl,2),2) + \
                    (2.45074*wl)/(-0.053477487504000006 + pow(wl,2))))/(wl*sqrt(2.12441 + \
                    (80568.4*pow(wl,2))/(-3.1032697920999997e6 + pow(wl,2)) + \
                    (1.22537*pow(wl,2))/(-0.053477487504000006 + pow(wl,2)))) - \
                    (2*Pi*sqrt(2.12441 + (80568.4*pow(wl,2))/(-3.1032697920999997e6 + \
                    pow(wl,2)) + (1.22537*pow(wl,2))/(-0.053477487504000006 + \
                    pow(wl,2))))/pow(wl,2)))/(c_mant*Pi);
        
    return( ret );
}


double Kappa_exact(int n, double *x, void *user_data) {
    
    double A = ((double *)user_data)[0];         // k_p'(w_p)-k_s'(w_s) [um-1 / (Trad/s)]
    double B = ((double *)user_data)[1];         // k_p'(w_p)-k_s'(w_i) [um-1 / (Trad/s)]
    double L = ((double *)user_data)[2];         // crystal length [mm]
    double sp = ((double *)user_data)[3];        // sigma pump [Trad/s]
    double ws0 = ((double *)user_data)[4];       // central signal omega [Trad/s]
    double wi0 = ((double *)user_data)[5];       // central idler omega [Trad/s]
    double pper = ((double *)user_data)[6];      // poling period [mm]
    
    double wls0 = 2*Pi*c_mant*1e2/ws0;           // central signal wl [um]
    double wli0 = 2*Pi*c_mant*1e2/wi0;           // central idler wl  [um]
    double wlp0 = 1/(1/wls0 + 1/wli0);           // corresp pump wl [um]
    
    //double A = kxPrime(wlp0) - kxPrime(wls0);    // [ mm-1 / Trad/s ]
    //double B = kxPrime(wlp0) - kzPrime(wli0);    // [ mm-1 / Trad/s ]
    
    double ws = (ws0 + x[0]*sp);                 // signal angular frequency [Trad/s]
    double wi = (wi0 + x[1]*sp);                 // idler angular frequency [Trad/s]
    
    double wls = 2*Pi*c_mant*1e2/ws;             // signal wavelength [um]
    double wli = 2*Pi*c_mant*1e2/wi;             // idler wavelength [um]
    double wlp = 1/(1/wls + 1/wli);              // sum of signal and idler [um]
    
    double dk0 = kx(wlp0) - kx(wls0) - kz(wli0); // deltaK central [mm-1]
    
    double arg1 = (A*x[0] + B*x[1]) * sp * L/2;
    //double arg1 = (kx(wlp) - kx(wls) - kz(wli) - dk0) * L/2;
    double pepm = exp( -(x[1] + x[0])*(x[1] + x[0]) ) * sinc(arg1)*sinc(arg1);
       
    // [ ws ] = [ wi ] = [ wi ] = Trad/s
    double prod_w = ws * wi * (ws + wi);
    
    // [kxPrime] = mm-1 / (Trad/s)
    double prod_dkdw = kxPrime(wlp) * kxPrime(wls) * kzPrime(wli);
    
    return( pepm * prod_w * prod_dkdw );

}


double JSI_with_Taylor(int n, double *x, void *user_data) {
    
    double A = ((double *)user_data)[0];         // k_p'(w_p) - k_s'(w_s) [um-1 / (Trad/s)]
    double B = ((double *)user_data)[1];         // k_p'(w_p) - k_s'(w_i) [um-1 / (Trad/s)]
    double L = ((double *)user_data)[2];         // crystal length [mm]
    double sp = ((double *)user_data)[3];        // sigma pump [Trad/s]
    double ws0 = ((double *)user_data)[4];       // central signal omega [Trad/s]
    double wi0 = ((double *)user_data)[5];       // central idler omega [Trad/s]

    double arg1 = (A*x[0] + B*x[1]) * sp * L/2;

    double pef2 = exp( -pow((x[1] + x[0]),2) ); 
    double pmf2 = pow(sinc(arg1), 2);
    
    return( pef2 * pmf2 );
    
}




double integrand(int n, double *x, void *user_data) {
        
    double L = ((double *)user_data)[2];         // crystal length [mm]
    double sp = ((double *)user_data)[3];        // sigma pump [Trad/s]
    double ws0 = ((double *)user_data)[4];       // central signal omega [Trad/s]
    double wi0 = ((double *)user_data)[5];       // central idler omega [Trad/s]
    double pper = ((double *)user_data)[6];      // poling period [mm]
    
    double taylor = ((double *)user_data)[7];    // use Taylor around center?
    double mode = ((double *)user_data)[8];      // what to integrate 
    
    double wls0 = 2*Pi*c_mant*1e2/ws0;           // central signal wl [um]
    double wli0 = 2*Pi*c_mant*1e2/wi0;           // central idler wl  [um]
    double wlp0 = 1/(1/wls0 + 1/wli0);           // corresp pump wl [um]
    
    
    //double A = ((double *)user_data)[0];         // k_p'(w_p)-k_s'(w_s) [um-1 / (Trad/s)]
    //double B = ((double *)user_data)[1];         // k_p'(w_p)-k_s'(w_i) [um-1 / (Trad/s)]
    
    double A = kyPrime(wlp0) - kyPrime(wls0);    // [ mm-1 / Trad/s ]
    double B = kyPrime(wlp0) - kzPrime(wli0);    // [ mm-1 / Trad/s ]
    
    double ws = (ws0 + x[0]*sp);                 // signal angular frequency [Trad/s]
    double wi = (wi0 + x[1]*sp);                 // idler angular frequency [Trad/s]
    
    double wls = 2*Pi*c_mant*1e2/ws;             // signal wavelength [um]
    double wli = 2*Pi*c_mant*1e2/wi;             // idler wavelength [um]
    double wlp = 1/(1/wls + 1/wli);              // sum of signal and idler [um]
    
    double dk0 = ky(wlp0) - ky(wls0) - kz(wli0); // deltaK central [mm-1]
    
    double arg1;
    
    if ( taylor == 1. ) {
        arg1 = (A*x[0] + B*x[1]) * sp * L/2;
    }
    else {
        arg1 = (kx(wlp) - kx(wls) - kz(wli) - dk0) * L/2;
    }
    
    double jsi = exp( -(x[1] + x[0])*(x[1] + x[0]) ) * sinc(arg1)*sinc(arg1);
    
    if ( mode == 0. ) {
        
        double prod_w = ws * wi * (ws + wi);     // [w] = Trad/s
        // [kxPrime] = mm-1 / (Trad/s)
        double prod_dkdw = kxPrime(wlp) * kxPrime(wls) * kzPrime(wli);
        return( jsi * prod_w * prod_dkdw);  
    }
    else if ( mode == 1. ) {
        
        double prod_w = ws * wi * (ws + wi);     // [w] = Trad/s
        return( jsi * prod_w );  
    }
    else {
        return( jsi );
    }
       
}





double f_real(int n, double *x, void *user_data) {

    double ws1 = ((double *)user_data)[0];
    double ws2 = ((double *)user_data)[1];
    double a = ((double *)user_data)[2];
    double b = ((double *)user_data)[3];
    double L = ((double *)user_data)[4];
    double sp = ((double *)user_data)[5];

    double arg1 = (a*ws1 + b*x[0])*sp*L/2;
    double arg2 = (a*x[0] + b*ws2)*sp*L/2;
    //double arg2 = (a*ws2 + b*x[0])*sp*L/2;

    return( exp( - (ws1 + x[0])*(ws1 + x[0])/2) * sinc(arg1) *
            exp( - (ws2 + x[0])*(ws2 + x[0])/2) * sinc(arg2) * cos( arg2 - arg1 ));
    
}


double f_imag(int n, double *x, void *user_data) {

    double ws1 = ((double *)user_data)[0];
    double ws2 = ((double *)user_data)[1];
    double a = ((double *)user_data)[2];
    double b = ((double *)user_data)[3];
    double L = ((double *)user_data)[4];
    double sp = ((double *)user_data)[5];

    double arg1 = (a*ws1 + b*x[0])*sp*L/2;
    double arg2 = (a*x[0] + b*ws2)*sp*L/2;
    //double arg2 = (a*ws2 + b*x[0])*sp*L/2;

    return( exp( - (ws1 + x[0])*(ws1 + x[0])/2) * sinc(arg1) *
            exp( - (ws2 + x[0])*(ws2 + x[0])/2) * sinc(arg2) * sin( arg2 - arg1 ));
    
}


int main() {
   return 0;
};













