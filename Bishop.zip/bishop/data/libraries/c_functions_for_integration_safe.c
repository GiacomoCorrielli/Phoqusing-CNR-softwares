#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 11:30:18 2022

@author: hdn
"""
/* testlib.c */
/*
double f(int n, double *x, void *user_data) {
    double c = *(double *)user_data;
    return c + x[0] - x[1] * x[2];
}
*/

#include <math.h>
#include <complex.h>

#define double PI = 3.1415926;
#define double T = 25;

double sinc(const double x) {

    if (x==0)
        return 1;
    
    return (sin(x)/x);

}


double kxPrime(const double w) {

   double ret = (1/1000000)*
   ((1/300000000)*w*((6.64792707493146e31/((-31.45571 + (3.6e29*PI*PI)/(w*w))**2*(w*w*w)) + 
       2.9419316798767156e29/( (-0.03978 + (3.6e29*PI*PI)/(w*w))*(-0.03978 + (3.6e29*PI**2)/(w*w)) *w*w*w))/
      (2*sqrt(3.291 + 9.35522/(-31.45571 + (3.6e29*PI*PI)/(w*w)) + 
         0.0414/(-0.03978 + (3.6e29*PI*PI)/w*w))) + 
     ((-20 + T)*(4.464826670204637e-16 - 3.0131794224301897e-31*w + 7.691095086361601e-47*w*w))/100000) + 
   (1/300000000)*(sqrt(3.291 + 9.35522/(-31.45571 + (3.6e29*PI*PI)/(w*w)) + 
       0.0414/(-0.03978 + (3.6e29*PI*PI)/(w*w))) + 
     ((-20 + T)*(0.1627 + 4.464826670204637e-16*w - 1.5065897112150948e-31*w*w + 
        2.5636983621205336e-47*w*w*w))/100000));
        
    return( ret );

}
        

double kyPrime(const double w) {
    
    double ret = (1/1000000)*
  ((1/300000000)*w*((1.2072046101610052e32/( (-39.43799 + (3.6e29*PI*PI)/(w*w))*(-39.43799 + (3.6e29*PI*PI)/(w*w))*(w*w*w)) + 
       3.0847645947692806e29/( (-0.04597 + (3.6e29*(PI*PI))/(w*w))*(-0.04597 + (3.6e29*(PI*PI))/(w*w))*(w*w*w)))/
      (2*sqrt(3.45018 + 16.98825/(-39.43799 + (3.6e29*(PI*PI))/(w*w)) + 
         0.04341/(-0.04597 + (3.6e29*(PI*PI))/(w*w)))) + 
     ((-20 + T)*(2.734281922318762e-16 - 2.2870442729934353e-31*w + 8.94532142543047e-47*(w*w)))/100000) + 
   (1/300000000)*(sqrt(3.45018 + 16.98825/(-39.43799 + (3.6e29*(PI*PI))/(w*w)) + 
       0.04341/(-0.04597 + (3.6e29*(PI*PI))/(w*w))) + 
     ((-20 + T)*(0.5425 + 2.734281922318762e-16*w - 1.1435221364967177e-31*(w*w) + 2.981773808476823e-47*(w*w*w)))/
      100000));
      
    return( ret );
}


double kzPrime(const double w) {
    
    double ret = (1/1000000)*
      ((1/300000000)*w*((7.874053137952388e32/((-86.12171 + (3.6e29*(PI*PI))/(w*w))*(-86.12171 + (3.6e29*(PI*PI))/(w*w))*(w*w*w)) + 
           4.41005507374756e29/((-0.04763 + (3.6e29*(PI*PI))/(w*w))*(-0.04763 + (3.6e29*(PI*PI))/(w*w))*(w*w*w)))/
          (2*sqrt(4.59423 + 110.80672/(-86.12171 + (3.6e29*(PI*PI))/(w*w)) + 
             0.06206/(-0.04763 + (3.6e29*(PI*PI))/(w*w)))) + 
         ((-20 + T)*(1.945775282593815e-15 - 1.64478054779395e-30*w + 4.13043609734073e-46*(w*w)))/100000) + 
       (1/300000000)*(sqrt(4.59423 + 110.80672/(-86.12171 + (3.6e29*(PI*PI))/(w*w)) + 
           0.06206/(-0.04763 + (3.6e29*(PI*PI))/(w*w))) + 
         ((-20 + T)*(-0.1897 + 1.945775282593815e-15*w - 8.22390273896975e-31*(w*w) + 1.3768120324469099e-46*(w*w*w)))/
          100000));
    
  return( ret );   
}

double Kappa_exact(int n, double *x, void *user_data) {

    double L = ((double *)user_data)[2];    // crystal length [um]
    double sp = ((double *)user_data)[3];   // sigma pump [rad/s]
    double ws0 = ((double *)user_data)[4];  // central signal omega [rad/s]
    double wi0 = ((double *)user_data)[5];  // central idler omega [rad/s]
    
    double a = kxPrime(ws0+wi0) - kxPrime(ws0);
    double b = kxPrime(ws0+wi0) - kzPrime(ws0);
    
    double pefsq = exp( -(x[1] + x[0])*(x[1] + x[0]) );
    
    double arg1 = (a*x[0] + b*x[1]) * sp * L/2;
    double pmfsq = sinc(arg1) * sinc(arg1);
    
    double ws = (ws0 + x[0]*sp);
    double wi = (wi0 + x[1]*sp);
    
    // this is the product omega_sig * omega_idl * (omega_s + omega_i)
    // in general won't make much of a change
    double prod_w = ws * wi * (ws + wi);
    
    // product of the dk/dw at frequencies of signal, idler and pumo
    double prod_dkdw = kxPrime(ws+wi) * kxPrime(ws) * kzPrime(wi);
    
    double ret = prod_w * prod_dkdw * pefsq * pmfsq;
    
    return(ret);

}







double Kappa_dont_integrate_omegas(int n, double *x, void *user_data) {

    double a = ((double *)user_data)[0];    // k_p'(w_p) - k_s'(w_s) [um/(rad/s)]
    double b = ((double *)user_data)[1];    // k_p'(w_p) - k_s'(w_i) [um/(rad/s)]
    double L = ((double *)user_data)[2];    // crystal length [um]
    double sp = ((double *)user_data)[3];   // sigma pump [rad/s]
    double ws0 = ((double *)user_data)[4];  // central signal omega [rad/s]
    double wi0 = ((double *)user_data)[5];  // central idler omega [rad/s]

    double arg1 = (a*x[0] + b*x[1]) * sp * L/2;

    double term1 = exp( -(x[1] + x[0])*(x[1] + x[0]) ) * sinc(arg1) * sinc(arg1);
    
    return( term1 );
    
}


double Kappa_also_integrate_omegas(int n, double *x, void *user_data) {
    
    double a = ((double *)user_data)[0];    // k_p'(w_p) - k_s'(w_s)
    double b = ((double *)user_data)[1];    // k_p'(w_p) - k_s'(w_i)
    double L = ((double *)user_data)[2];    // crystal length [um]
    double sp = ((double *)user_data)[3];   // sigma pump [rad/s]
    double ws0 = ((double *)user_data)[4];  // central signal omega [rad/s]
    double wi0 = ((double *)user_data)[5];  // central idler omega [rad/s]
    
    double arg1 = (a*x[0] + b*x[1]) * sp * L/2;

    double term1 = exp( -(x[1] + x[0])*(x[1] + x[0]) ) * sinc(arg1) * sinc(arg1);
    
    // this is the product omega_sig * omega_idl * (omega_s + omega_i)
    // in general won't make much of a change
    double term2 = (ws0 + x[0]*sp) * (wi0 + x[1]*sp) * ((ws0 + x[0]*sp) + (wi0 + x[1]*sp));

    return( term1 * term2 );
    
}






double f_real(int n, double *x, void *user_data) {

    double ws1 = ((double *)user_data)[0];
    double ws2 = ((double *)user_data)[1];
    double a = ((double *)user_data)[2];
    double b = ((double *)user_data)[3];
    double L = ((double *)user_data)[4];
    double sp = ((double *)user_data)[5];

    double arg1 = (a*ws1 + b*x[0])*sp*L/2;
    double arg2 = (a*x[0] + b*ws2)*sp*L/2;
    //double arg2 = (a*ws2 + b*x[0])*sp*L/2;

    return( exp( - (ws1 + x[0])*(ws1 + x[0])/2) * sinc(arg1) *
            exp( - (ws2 + x[0])*(ws2 + x[0])/2) * sinc(arg2) * cos( arg2 - arg1 ));
    
}


double f_imag(int n, double *x, void *user_data) {

    double ws1 = ((double *)user_data)[0];
    double ws2 = ((double *)user_data)[1];
    double a = ((double *)user_data)[2];
    double b = ((double *)user_data)[3];
    double L = ((double *)user_data)[4];
    double sp = ((double *)user_data)[5];

    double arg1 = (a*ws1 + b*x[0])*sp*L/2;
    double arg2 = (a*x[0] + b*ws2)*sp*L/2;
    //double arg2 = (a*ws2 + b*x[0])*sp*L/2;

    return( exp( - (ws1 + x[0])*(ws1 + x[0])/2) * sinc(arg1) *
            exp( - (ws2 + x[0])*(ws2 + x[0])/2) * sinc(arg2) * sin( arg2 - arg1 ));
    
}














