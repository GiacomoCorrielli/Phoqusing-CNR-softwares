#include <math.h>
#include <complex.h>

#define c 2.99792458e8
#define c_mant 2.99792458
#define Pi 3.14159259

double sinc(const double x) {

    if (x==0)
        return 1;
    
    return (sin(x)/x);

}



double ky(const double wl, const double T) {

    // wl: wavelength [um]
    // returns value in mm-1

    double ret = (2*Pi*sqrt(3.06931 + 1.72724e-6/pow(wl,10) - 0.0000277402/pow(wl,8) \
                  + 0.000624201/pow(wl,6) - 0.00180292/pow(wl,4) + 0.0587431/pow(wl,2) \
                  - 0.0221518*pow(wl,2) + 0.000300864*pow(wl,4) + 0.000229511*pow(wl,6) \
                  - 0.0000346132*pow(wl,8)))/wl;
    
    return( ret );

}


double kyPrime(const double wl, const double T) {
    
    // wl: wavelength [um]
    // returns value in um-1 / Prad/s (order of unity)
    
    double ret = -5.*(pow(wl,2)*((Pi*(-0.0000172724/pow(wl,11) + \
                    0.0002219216/pow(wl,9) - 0.003745206/pow(wl,7) + 0.00721168/pow(wl,5) \
                    - 0.1174862/pow(wl,3) - 0.0443036*wl + 0.001203456*pow(wl,3) + \
                    0.0013770660000000001*pow(wl,5) - \
                    0.0002769056*pow(wl,7)))/(wl*sqrt(3.06931 + 1.72724e-6/pow(wl,10) - \
                    0.0000277402/pow(wl,8) + 0.000624201/pow(wl,6) - 0.00180292/pow(wl,4) \
                    + 0.0587431/pow(wl,2) - 0.0221518*pow(wl,2) + 0.000300864*pow(wl,4) + \
                    0.000229511*pow(wl,6) - 0.0000346132*pow(wl,8))) - (2*Pi*sqrt(3.06931 \
                    + 1.72724e-6/pow(wl,10) - 0.0000277402/pow(wl,8) + \
                    0.000624201/pow(wl,6) - 0.00180292/pow(wl,4) + 0.0587431/pow(wl,2) - \
                    0.0221518*pow(wl,2) + 0.000300864*pow(wl,4) + 0.000229511*pow(wl,6) - \
                    0.0000346132*pow(wl,8)))/pow(wl,2)))/(c_mant*Pi);
    
    return( ret );   
}

                                                              
                                                              
double kz(const double wl, const double T) {
        
    // wl: wavelength [um]
    // returns value in mm-1

    double ret = (2*Pi*sqrt(3.32184 + 3.57927e-6/pow(wl,10) - 0.0000761753/pow(wl,8) \
                + 0.0015029/pow(wl,6) - 0.00589531/pow(wl,4) + 0.0930534/pow(wl,2) - \
                0.0131747*pow(wl,2) - 0.00585668*pow(wl,4) + 0.00176745*pow(wl,6) - \
                0.000171804*pow(wl,8)))/wl;
    
    return( ret );
    
}
                                                    

double kzPrime(const double wl, const double T) {
    
    // wl: wavelength [um]
    // returns value in um-1 / Prad/s (order of unity)
    
    double ret = -5.*(pow(wl,2)*((Pi*(-0.0000357927/pow(wl,11) + \
                0.0006094024/pow(wl,9) - 0.0090174/pow(wl,7) + 0.02358124/pow(wl,5) - \
                0.1861068/pow(wl,3) - 0.0263494*wl - 0.02342672*pow(wl,3) + \
                0.0106047*pow(wl,5) - 0.001374432*pow(wl,7)))/(wl*sqrt(3.32184 + \
                3.57927e-6/pow(wl,10) - 0.0000761753/pow(wl,8) + 0.0015029/pow(wl,6) \
                - 0.00589531/pow(wl,4) + 0.0930534/pow(wl,2) - 0.0131747*pow(wl,2) - \
                0.00585668*pow(wl,4) + 0.00176745*pow(wl,6) - 0.000171804*pow(wl,8))) \
                - (2*Pi*sqrt(3.32184 + 3.57927e-6/pow(wl,10) - 0.0000761753/pow(wl,8) \
                + 0.0015029/pow(wl,6) - 0.00589531/pow(wl,4) + 0.0930534/pow(wl,2) - \
                0.0131747*pow(wl,2) - 0.00585668*pow(wl,4) + 0.00176745*pow(wl,6) - \
                0.000171804*pow(wl,8)))/pow(wl,2)))/(c_mant*Pi);
        
    return( ret );
}


double Kappa_exact(int n, double *x, void *user_data) {
    
    double A = ((double *)user_data)[0];         // k_p'(w_p)-k_s'(w_s) [um-1 / (Trad/s)]
    double B = ((double *)user_data)[1];         // k_p'(w_p)-k_s'(w_i) [um-1 / (Trad/s)]
    double L = ((double *)user_data)[2];         // crystal length [mm]
    double sp = ((double *)user_data)[3];        // sigma pump [Trad/s]
    double ws0 = ((double *)user_data)[4];       // central signal omega [Trad/s]
    double wi0 = ((double *)user_data)[5];       // central idler omega [Trad/s]
    double pper = ((double *)user_data)[6];      // poling period [mm]
    double T = ((double *)user_data)[7];         // temperature [ºC]
    
    double wls0 = 2*Pi*c_mant*1e2/ws0;           // central signal wl [um]
    double wli0 = 2*Pi*c_mant*1e2/wi0;           // central idler wl  [um]
    double wlp0 = 1/(1/wls0 + 1/wli0);           // corresp pump wl [um]
    
    //double A = kxPrime(wlp0) - kxPrime(wls0);    // [ mm-1 / Trad/s ]
    //double B = kxPrime(wlp0) - kzPrime(wli0);    // [ mm-1 / Trad/s ]
    
    double ws = (ws0 + x[0]*sp);                 // signal angular frequency [Trad/s]
    double wi = (wi0 + x[1]*sp);                 // idler angular frequency [Trad/s]
    
    double wls = 2*Pi*c_mant*1e2/ws;             // signal wavelength [um]
    double wli = 2*Pi*c_mant*1e2/wi;             // idler wavelength [um]
    double wlp = 1/(1/wls + 1/wli);              // sum of signal and idler [um]
    
    double dk0 = ky(wlp0, T) - ky(wls0, T) - kz(wli0, T); // deltaK central [mm-1]
    
    double arg1 = (A*x[0] + B*x[1]) * sp * L/2;
    //double arg1 = (kx(wlp) - kx(wls) - kz(wli) - dk0) * L/2;
    double pepm = exp( -(x[1] + x[0])*(x[1] + x[0]) ) * sinc(arg1)*sinc(arg1);
       
    // [ ws ] = [ wi ] = [ wi ] = Trad/s
    double prod_w = ws * wi * (ws + wi);
    
    // [kxPrime] = mm-1 / (Trad/s)
    double prod_dkdw = kyPrime(wlp, T) * kyPrime(wls, T) * kzPrime(wli, T);
    
    return( pepm * prod_w * prod_dkdw );

}


double JSI_with_Taylor(int n, double *x, void *user_data) {
    
    double A = ((double *)user_data)[0];         // k_p'(w_p) - k_s'(w_s) [um-1 / (Trad/s)]
    double B = ((double *)user_data)[1];         // k_p'(w_p) - k_s'(w_i) [um-1 / (Trad/s)]
    double L = ((double *)user_data)[2];         // crystal length [mm]
    double sp = ((double *)user_data)[3];        // sigma pump [Trad/s]
    double ws0 = ((double *)user_data)[4];       // central signal omega [Trad/s]
    double wi0 = ((double *)user_data)[5];       // central idler omega [Trad/s]

    double arg1 = (A*x[0] + B*x[1]) * sp * L/2;

    double pef2 = exp( -pow((x[1] + x[0]),2) ); 
    double pmf2 = pow(sinc(arg1), 2);
    
    return( pef2 * pmf2 );
    
}




double integrand(int n, double *x, void *user_data) {
        
    double L = ((double *)user_data)[2];         // crystal length [mm]
    double sp = ((double *)user_data)[3];        // sigma pump [Trad/s]
    double ws0 = ((double *)user_data)[4];       // central signal omega [Trad/s]
    double wi0 = ((double *)user_data)[5];       // central idler omega [Trad/s]
    double pper = ((double *)user_data)[6];      // poling period [mm]
    double T = ((double *)user_data)[7];         // temperature [ºC]
    
    double taylor = ((double *)user_data)[8];    // use Taylor around center?
    double mode = ((double *)user_data)[9];      // what to integrate 
    
    double wls0 = 2*Pi*c_mant*1e2/ws0;           // central signal wl [um]
    double wli0 = 2*Pi*c_mant*1e2/wi0;           // central idler wl  [um]
    double wlp0 = 1/(1/wls0 + 1/wli0);           // corresp pump wl [um]
    
    
    double A = ((double *)user_data)[0];         // k_p'(w_p)-k_s'(w_s) [mm-1 / (Trad/s)]
    double B = ((double *)user_data)[1];         // k_p'(w_p)-k_s'(w_i) [mm-1 / (Trad/s)]
    
    // double A = kyPrime(wlp0, T) - kyPrime(wls0, T);    // [ mm-1 / Trad/s ]
    // double B = kyPrime(wlp0, T) - kzPrime(wli0, T);    // [ mm-1 / Trad/s ]
    
    double ws = (ws0 + x[0]*sp);                 // signal angular frequency [Trad/s]
    double wi = (wi0 + x[1]*sp);                 // idler angular frequency [Trad/s]
    
    double wls = 2*Pi*c_mant*1e2/ws;             // signal wavelength [um]
    double wli = 2*Pi*c_mant*1e2/wi;             // idler wavelength [um]
    double wlp = 1/(1/wls + 1/wli);              // sum of signal and idler [um]
    
    double dk0 = ky(wlp0, T) - ky(wls0, T) - kz(wli0, T); // deltaK central [mm-1]
    
    double arg1;
    
    if ( taylor == 1. ) {
        arg1 = (A*x[0] + B*x[1]) * sp * L/2;
    }
    else {
        arg1 = (ky(wlp, T) - ky(wls, T) - kz(wli, T) - dk0) * L/2;
    }
    
    double jsi = exp( -(x[1] + x[0])*(x[1] + x[0]) ) * sinc(arg1)*sinc(arg1);
    
    if ( mode == 0. ) {
        
        double prod_w = ws * wi * (ws + wi);     // [w] = Trad/s
        // [kxPrime] = mm-1 / (Trad/s)
        double prod_dkdw = kyPrime(wlp, T) * kyPrime(wls, T) * kzPrime(wli, T);
        return( jsi * prod_w * prod_dkdw);  
    }
    else if ( mode == 1. ) {
        
        double prod_w = ws * wi * (ws + wi);     // [w] = Trad/s
        return( jsi * prod_w );  
    }
    else {
        return( jsi );
    }
       
}



int main() {
   return 0;
};













