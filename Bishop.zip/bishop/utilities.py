import os
import sys
import numpy as np

import scipy.stats
import scipy.signal

from scipy.optimize import curve_fit

from numba import njit

import bishop


DTYPE_LIST = [ ('confs', 'U12'),
               ('wls_signal', 'float'),
               ('wls_idler', 'float'),
               ('poling_period', 'float'),
               ('A', 'float'), 
               ('B', 'float'),
               ('slopes', 'float'),
               ('pJSI', 'float'),
               ('JSI_gamma', 'float'),
               ('pJSA', 'float'),
               ('JSA_gamma', 'float'),
               ('pJSAnp', 'float'),
               ('abs(JSA)_gamma', 'float'),
               ('visibs', 'float'),
               ('etas', 'float'),
               ('lengths', 'float'),
               ('sigma_pump', 'float') ]



PATH_TO_BISHOP_DATA = os.path.join(os.path.dirname(bishop.__file__), 'data')

def PATH_TO_LIBRARY(conf, mat):
    return os.path.join(PATH_TO_BISHOP_DATA, 'libraries', 
                        f'c_functions_for_integration_{mat}_{conf}.so')



def change_global_parameter(par, value,
                            path_to_gp='/home/hjdno/spyder-env/lib/python3.8/' 
                                       'site-packages/bishop/global_parameters.py'):
    
    os.system(f"sed -i '/{par:s} = /c\{par:s} = {value:f}  ' {path_to_gp:s}")
    
    return 
    


def parse_iterables(*iterables):
    
    ret = []
    
    for itr in iterables:
        if isinstance(itr, tuple) or isinstance(itr, list):
            ret.append(np.array(itr))
        else:
            ret.append(itr)
    
    return ret
        

def hmean(a, b):
    
    """
    Compute harmonic mean between two quantities, a and b. Harmonic mean is
    given by the expression 1/hmean = (1/a + 1/b).
    """
    
    [a, b] = parse_iterables(a, b)
    
    return 1/(1/a + 1/b)


def slice_with_other_arr_argmax(source_arr, target_arr, axis):
    
    """
    Reduces the number of dimensions of a given array by one, thus collapsing
    one of the dimensions into a single value, which is the maximum of another
    array along the given dimension.
    
    Parameters
    ----------
    source_arr : np.ndarray
        The array for which the maxima is going to be calculated.
    
    target_arr : np.ndarray
        The array which is going to be collapsed in one of its dimensions. Must
        have the same dimensions as the source array.
        
    axis : int
        The dimension along which the collapsing (and maximizing of the source
        array) will be carried out.
        
    Returns
    -------
    np.ndarray
        The target_arr with one of its dimensions colapsed into a number. Its
        dimensions are those of target_arr, but without the dimension corres-
        ponding to the axis.
        
    Example
    -------
        >>>  ls = np.arange(30)
        >>>  sa = ls.reshape(5,2,3)
        >>>  ta = np.cos(np.pi/2 * ls/29).reshape(5,2,3)
        
        >>>  sliced0 = slice_with_other_arr_argmax(sa, ta, 0)
        
        # compare the same (j,k) element for all 5 \'rows\'
        # so sliced0[1,2] contains the element of ta at position (imax, 1, 2)
        # where imax is the one where sa[:, 1, 2] is max
        # sliced0 has dimensions (2,3) (same as sa without axis 0)
        
        >>>  print(sliced0)
        array([[9.76620556e-01, 8.83512044e-01, 7.25995492e-01],
               [5.15553857e-01, 2.67528339e-01, 6.12323400e-17]])

    """
    
    out_shape = list(np.shape(source_arr))
    out_shape.pop(axis)
    
    out_arr = target_arr.ravel()
    
    argmaxs = np.argmax(source_arr, axis=axis)
    off = np.arange(0, source_arr.size, source_arr.shape[axis]).reshape(out_shape)
    
    # the argmaxs as coordinates of a flattened array 
    argmaxs = (argmaxs + off).ravel()
    
    out_arr = out_arr[argmaxs].reshape(out_shape)
    
    return out_arr


def get_fit_parameters(x, y):

    """
    Calculates the parameters, and the r^2 of the fit of inputs x and y after 
    doing a linear fit.

    Parameters
    ----------
    x / y : np.ndarray 
        Arrays with the data to fit (must have the same shape)
    

    Returns
    -------
    slope : float
        Slope of the linear regression (a in y = mx + b).
    
    intercept : float
        Intercept of the linear regression (b in y = mx + b).
        
    rvalue : float 
        Correlation coefficient of the fit, 0 <= r2 <= 1, the closer to one the
        better the linear correlation.
    """
    
    lr = scipy.stats.linregress(np.ravel(x), np.ravel(y))
    
    return lr.slope, lr.intercept, lr.rvalue


def normal(array, njump=1):
    
    """
    Normalized array
    """
    return array[::njump, ::njump]/np.sqrt(np.sum(np.abs(array[::njump, ::njump])**2))




def find_index_of_nearest(data, value):

    if isinstance(data, list):
        data = [abs(dataval - value) for dataval in data]
        indice = data.index(min(data))

    elif data.ndim == 1:
        indice = np.unravel_index(np.ma.argmin(np.ma.abs(data-value), axis=None), data.shape)[0]
        
    else:
        indice = np.unravel_index(np.ma.argmin(np.ma.abs(data-value), axis=None), data.shape)

    return indice


@njit
def make_two_arrays_same_size(mode1, mode2, 
                              mode='centred', offs_info=False):

    max_size_i = int(max(np.shape(mode1)[0], np.shape(mode2)[0]))
    max_size_j = int(max(np.shape(mode1)[1], np.shape(mode2)[1]))

    # make them the same size    
    data1 = padding(mode1, max_size_i, max_size_j, mode=mode, offs_info=offs_info)
    data2 = padding(mode2, max_size_i, max_size_j, mode=mode, offs_info=offs_info)

    return data1, data2


@njit
def padding(array, xx, yy, mode='centred', offs_info=False):
    """
    :param array: numpy array
    :param xx: desired height
    :param yy: desirex width
    :return: padded array
    """

    h, w = np.shape(array)

    if mode == 'top-left':
        a = 0
        aa = xx - h

        b = 0
        bb = yy - w
        
    elif mode == 'centred':
        a = (xx - h) // 2
        aa = xx - a - h

        b = (yy - w) // 2
        bb = yy - b - w
    
    if offs_info:
        return [np.pad(array, pad_width=((a, aa), (b, bb)), mode='constant'), [a,aa,b,bb]]

    else:
        return np.pad(array, pad_width=((a, aa), (b, bb)), mode='constant')
   

def compute_overlap_integral(mode1, mode2, debug=0, align_maxima=True,
                             find_corners=True, input_is_square=True,
                             adjust_scales=None):

    """
    Compute the overlap integral between the two modes. Instead of computing
    the convolution and finding the maximum, the procedure is: 
    1) determine the maxima of the two mode distributions,
    2) shift one of the maxima to coincide with the other,
    3) allow for some dislocation of one of the arrays over the other, while
       computing the overlap term-times-term sum.
    4) find the maximum over the set of all performed dislocations in order
       to find the global maximum of the convolution without having to com-
       pute it entirely.

    Inputs:
    =======

    mode1, mode2  == 2D arrays with the intensity data (mode profiles). Then,
    (np.ndarrays)    the square root of these profiles is taken, and that
                     is further divided by the square root of the sum of the 
                     mode profile. In that way, by the Cauchy Schwartz ineq,
                       _                       _              _           
                0 < (_/ E1(x,y)E2(x,y))^2 / (_/ E1(x,y)^2)*(_/ E2(x,y)^2) < 1 

                if we have that

                E{i} = Sqrt(mode{i})/Sqrt(Sum(modei)), then
                   _
                (_/ Ei(x,y)^2) ~ Sum(Ei^2) = Sum(Sqrt(mode{i})^2)/Sum(mode{i})
                                           = 1
                                              _
                and therefore the value of (_/ E1(x,y)E2(x,y))^2 is contained
                betweeen 0 and 1*1 = 1.

                This is why the output is not the maximum overlapped sum of E1
                and E2 defined above, but the respective square.
    
    align_maxima  == align the maxima of the two arrays and then do the slide
    (bool)           in x and y to maximize the overlap

    debug         == print some relevant parameters to check what is going on
    (bool)
    

    Outputs:
    ========
    oli           == overlap integral between the two modes (see Inputs above
    (float)          for an explanation on how it is computed)

    """


    if not np.all(np.iscomplex(mode1)):
        mode1[mode1 < 0] = 0
        mode2[mode2 < 0] = 0

    if input_is_square:
        # no need to revert in this case!!!
        #campo1_rev = np.sqrt(mode1)[::-1, ::-1]/np.sqrt(np.sum(mode1))
        campo1_rev = np.sqrt(mode1)/np.sqrt(np.sum(mode1))

        campo1 = np.sqrt(mode1)/np.sqrt(np.sum(mode1))

        campo2 = np.sqrt(mode2)/np.sqrt(np.sum(mode2))
        
    else:
        campo1 = campo1 / np.sqrt(np.sum(np.abs(mode1)**2))
        campo2 = campo2 / np.sqrt(np.sum(np.abs(mode2)**2))


    campo1_ss, campo2_ss = utils.make_two_arrays_same_size(campo1, campo2,
                                                     mode='top-left')

    campo1_rev_ss, campo2_ss = utils.make_two_arrays_same_size(campo1_rev, campo2, 
                                                         mode='top-left')

    if adjust_scales is not None:

        # in this case we make sure that we take the image that has
        # larger microns per pixel, and interpolate it to get 
        # something with the same spacing as the other

        # adjust scales HAS to be given as (scale in y, scale in x)

        new_shape = [0., 0.]
    
        if adjust_scales[0][0] > adjust_scales[1][0]:
            # scale of the mode 1 is the biggest

            # take old nrows, get the corresponding length
            corr_length_i = np.shape(campo1)[0] * adjust_scales[0][0]
            corr_length_j = np.shape(campo1)[1] * adjust_scales[0][1]

            # then divide by the target scale (scale of mode 2)
            new_shape[0] = corr_length_i/adjust_scales[1][0]
            new_shape[1] = corr_length_j/adjust_scales[1][1]

            campo1 = compute_linear_interpolation(campo1, new_shape)

        else:
            # scale of the mode 2 is the biggest

            # take old nrows, get the corresponding length
            corr_length_i = np.shape(campo2)[0] * adjust_scales[1][0]
            corr_length_j = np.shape(campo2)[1] * adjust_scales[1][1]

            # then divide by the target scale (scale of mode 1)
            new_shape[0] = corr_length_i/adjust_scales[0][0]
            new_shape[1] = corr_length_j/adjust_scales[0][1]

            campo2 = compute_linear_interpolation(campo2, new_shape)


    """
    xtest1, ytest1 = np.mgrid[-15:10, -15:20]
    xtest2, ytest2 = np.mgrid[-20:21, -20:21]
    
    mode1 = np.exp(-(xtest1**2 + ytest1**2)/5**2)
    mode2 = np.exp(-(xtest2**2 + ytest2**2)/10**2)

    campo1_rev = mode1[::-1, ::-1]
    campo1_rev_ss, campo2_ss = make_two_arrays_same_size(campo1_rev, mode2)

    plt.imshow(campo1_rev_ss)
    plt.show()
    """

    if align_maxima:
        i01, j01 = estimate_maxpoints(campo1_rev_ss, running_window=0)
        i02, j02 = estimate_maxpoints(campo2_ss, running_window=0)
        difi, difj = i02-i01, j02-j01
        hsw = half_search_window
    else:
        hsw = 0
        difi, difj = 0, 0
    
    cur_max = 0
    # make the peak adjustment and then shift of a bit
    for i in range(-hsw, hsw+1):
        for j in range(-hsw, hsw+1):
            di = difi + i
            dj = difj + j

            campo1_rolled = revert_and_roll(campo1_rev_ss, di, dj)

            this_conv = np.abs(np.sum(campo1_rolled*campo2_ss))

            if this_conv > cur_max:
                
                #print(di, dj, this_conv)
                cur_max = this_conv

    if debug:
        
        print("Shape of the original modes: ", mode1.shape, mode2.shape)
        print("Shape of the resized modes: ", campo1_rev_ss.shape,
                                              campo2_ss.shape)

        print("Estimated maxpoints: ", i01, j01, i02, j02)
        
        # need to invert, because convolve2d will invert him again
        # before shifting and multiplying
        sp = scipy.signal.convolve2d(campo1[::-1, ::-1], campo2)

        print("Index of SP maximum: ", estimate_maxpoints(sp, 
                                                          running_window=0))
        print("Size of conv: ", sp.shape)
        print("Convolution scipy: %f" %np.max(sp)**2)
        print("Convolution my method: %f" %cur_max**2)

    return cur_max**2



def estimate_maxpoints(data, running_window=29):

    if running_window != 0:
        data = running_mean(data, running_window)

    if data.ndim == 1:
        return np.unravel_index(np.argmax(data, axis=None), data.shape)[0]
    else:
        return np.unravel_index(np.argmax(data, axis=None), data.shape)



def estimate_sigma(twoD_data, running_window=29, multiply_by=[1,1]):

    twoD_data = twoD_data / np.max(twoD_data)
    
    nrows, ncols = np.shape(twoD_data)

    # this is dangerous, let's make moving average before 
    #x0_est, y0_est = np.unravel_index(np.argmax(running_mean(data, 3), axis=None), twoD_data.shape)
    i0_est, j0_est = estimate_maxpoints(twoD_data, running_window=running_window)

    #print(np.max(twoD_data))
    #print(np.max(twoD_data[:, j0_est]), np.max(twoD_data[j0_est, :]))

    # plt.figure("Profile along Y")
    # plt.plot(twoD_data[:, j0_est], 'o')
    # plt.plot(0.5*np.ones(nrows))

    # plt.figure("Profile along X")
    # plt.plot(twoD_data[i0_est, :], 'o')
    # plt.plot(0.5*np.ones(ncols))
    # plt.show()
    
    try:
        method = "FWHM"
        above_fwhm_i = np.where(twoD_data[i0_est, :] > 0.5)[0]
        above_fwhm_j = np.where(twoD_data[:, j0_est] > 0.5)[0]

        sigma_i_est = (above_fwhm_i[-1] - above_fwhm_i[0])/2.355
        sigma_j_est = (above_fwhm_j[-1] - above_fwhm_j[0])/2.355

    except IndexError:
        method = "3s"
        above_3s_i = np.where(twoD_data[i0_est, :] > 0.1353)[0] # actually, above 2s
        above_3s_j = np.where(twoD_data[:, j0_est] > 0.1353)[0]

        sigma_i_est = (above_3s_i[-1] - above_3s_i[0])/4
        sigma_j_est = (above_3s_j[-1] - above_3s_j[0])/4

    sigma_i_est *= multiply_by[0]
    sigma_j_est *= multiply_by[1]

    # print("Est sigma method %s X/Y: %f %f" %(method, sigma_i_est, sigma_j_est))
    # print("1st Est %f %f 2nd Est %f %f" %(sigma_x_est, sigma_y_est, sigma_x_est_2, sigma_y_est_2))

    return sigma_i_est, sigma_j_est



def my_savetxt(filepath, array3D):
    
    if len(np.shape(array3D)) < 3:
        # 2D or 1D can be saved using regular numpy.savetxt
        np.savetxt(filepath, array3D)

    else:
        with open(filepath, 'w') as outfile:
            
            # outfile.write('# Array shape: {0}\n'.format(data.shape))
            for k in range(np.shape(array3D)[2]):

                np.savetxt(outfile, array3D[:, :, k], fmt='%.5f')

                # Writing out a break to indicate different slices...
                outfile.write('# New slice\n')



def get_var_or_raise_err(varname, dictionary):

    var = dictionary.get(varname, None)

    if var is None:
        raise ValueError('`{:s}` must be defined in the `optimization` dictionary'.format(varname))
    else:
        return var



def save_struct_array(array, folder_name, file_name, wl_p_str,
                      material,  configurations='',
                      crit_list='', signal_mode_str='', optpar='',
                      npts=[], start_end=[]):

    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    format_str = ('%s, '+', '.join(3*['%13.6f'] + 2*['%13.5e'] + 9*['%13.6f'] + ['%13.4f', '%13.8f']))
    
    nptssig, nptsid, nptsopt = npts
    start_stamp, end_stamp = start_end
    
    hl1 = f'Simulation start: {start_stamp:s}\n' +\
          f'Simulation end: {end_stamp:s}\n' +\
          f'Material: {material.name} at {material.T} degrees Celsius\n' +\
          f'Configurations: {configurations}\n' +\
          f'Pump wavelength: {wl_p_str}\n' +\
          f'Signal mode: {signal_mode_str}\n' +\
          f'Optimization parameter: {optpar}\n' +\
          f'N points (signals, idlers, opt parameter): ({nptssig}, {nptsid}, {nptsopt})'

    hl7 = '{:13s}'.format(DTYPE_LIST[0][0]) +\
                ' '.join(['{:14s}'.format(name) for (name, _) in DTYPE_LIST[1:]])

    list_with_criteria = []
    ncrits = len(crit_list)
    
    for i in range(ncrits):
        nts_per_crit = len(array)//ncrits
        
        list_with_criteria.append('{:s} (lines {:d}-{:d})'.format(crit_list[i], 
                                                                  7 + nts_per_crit*i, 
                                                                  6 + nts_per_crit*(i+1)))
    
    string_with_criteria = ' / '.join(list_with_criteria)

    hl6 = f'Optimization criteria: {string_with_criteria}'
    head = f'{hl1}\n{hl6}\n{hl7}'
    
    path_to_save = "{:s}/{:s}.txt".format(folder_name, file_name)
    
    np.savetxt(path_to_save, array, 
               fmt=format_str,
               header=head)



def solve_quadratic(b, c):
    
    """
    Returns the solutions of the quadratic equation x^2 + b x + c = 0.
    """
    
    delta = np.sqrt(b**2 - 4*c)
    return (-b/2 - delta/2), (-b/2 + delta/2)



def smallest_angle_2_vecs(v1, v2):

    norm1 = np.sum(v1**2)
    norm2 = np.sum(v2**2)

    return np.min([np.arccos(np.sum(v1*v2)/np.sqrt(norm1*norm2)),
                   np.arccos(np.sum(-v1*v2)/np.sqrt(norm1*norm2))])



def make_fit(x, y, fit_func, p0, pcov=False, **kwargs):
    
    fit_pars, covars = curve_fit(fit_func, x, y, p0, **kwargs)
    
    r = determine_fit_rsquared(y, fit_func(x, *fit_pars))
    
    if pcov:
        return fit_func(x, *fit_pars), r, fit_pars, covars
    else:
        return fit_func(x, *fit_pars), r, fit_pars
    


def determine_fit_rsquared(x, y):
    
    lr = scipy.stats.linregress(np.ravel(x), np.ravel(y))
    
    return lr.rvalue

def check_dict_integrity(d, name, req_fields, opt_fields):
    
    fields = d.keys()
    allowed_fields = req_fields | opt_fields
    
    if not (req_fields <= fields):
        miss_fields = req_fields - fields
        raise ValueError((f'Dictionary {name} does not have all required fields'
                          f', the following are missing: {miss_fields}.')) 
        
    elif not (fields <= allowed_fields):
        unallowed_fields = fields - allowed_fields
        raise ValueError((f'Dictionary {name} has the following unallowed '
                          f'parameters: {unallowed_fields}.'))
        
    




