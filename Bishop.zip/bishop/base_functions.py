import numpy as np

import bishop.settings as us
import bishop.base_optics as bop
import bishop.parsing_functions as ps
import bishop.utilities as utils

"""

Functions needed for the representation of the Joint Spectral Functions.

"""


###############################################################################
######################### JOINT SPECTRAL FUNCTIONS ############################
###############################################################################


def my_sinc(x):
    return np.sinc(x/us.PI)


def pump_env_sq(pump, sigma_pump, signal, idler,
                env_type='gaussian', mode='angfreq',
                filtering_data=None):
    
    """
    Pump envelope function for a gaussian profile:

    PEF = exp(- (wp - ws - wi)² / (2 sigma_p²)

    Args are the same as in ~.get_JSFs 
    ====
    
    Kwargs
    ======

    mode   == in ['wavelength', 'angfreq']
    (str)     the mode in which the *signal* and *idler* arguments are given
              (wavelength or angular frequency)

    square == whether to return the pump envelope function or the square 
    (bool)    of its norm

    """
    
    [wp, sigma_p, ws, wi], _ = ps.parse_args(pump, sigma_pump, signal, idler, 
                                             input_mode=mode)

    if env_type == 'gaussian':
        pef = np.exp(-(wp - ws - wi)**2/2/sigma_p**2)
    

    if filtering_data is not None:
        # do some filtering on the pump
        wf, sigma_f = filtering_data

        # convert to rad/s
        wf = bop.wl2w(wf)
        sigma_f *= wf**2/2/us.PI/us.C

        pef *= np.exp(-(wf - ws - wi)**2/2/sigma_f**2)
    
    return pef



def phase_match_sq(signal, idler, material, mode='angfreq'):
    
    '''Phase matching function, exactly as is for a quasi phase match crystal:

    PEF = sinc(deltaK * L / 2)
    
    Args are the same as in ~.get_JSFs 
    ====
    
    Kwargs are the same as in ~.pump_env_sq
    ======
    '''
    
    _, [wls, wli] = ps.parse_args(signal, idler, input_mode=mode)
    L = material.L
    
    wlp = 1/(1/wls + 1/wli)

    dk = material.dk(wlp, wls, wli)
    
    sinc = my_sinc(dk*L/2)
    phase = np.exp(-1j*dk*L/2)
    
    return [sinc, phase]





def phase_match_sq_approx(signal, idler, signal_0, idler_0, mat,
                          mode='angfreq'):
    
    """
    Phase matching function, in a first order approximation:

    PEF = sinc(deltaK * L / 2), with deltaK = A(ws-ws0) + B(wi - wi0)
    
    Args are the same as in ~.get_JSFs 
    ====
    
    Kwargs are the same as in ~pump_env_sq
    ======
    
    """
    
    
    [ws, wi], _ = ps.parse_args(signal, idler, input_mode=mode)
    [ws0, wi0], _ = ps.parse_args(signal_0, idler_0, input_mode=mode)
    
    L = mat.L

    # argmt comes in um^-1 / (rad/s) * (rad/s) = um^-1
    # L must come in um

    A, B = mat.A_and_B(ws0+wi0, ws0, wi0, mode='angfreq')

    argmt = A*(wi-wi0) + B*(ws-ws0)
    
    sinc = my_sinc(argmt*L/2)
    phase = np.exp(-1j*argmt*L/2)
    return [sinc, phase]
            

def get_gammas_from_lengths(length, A, B, fwhm):
    
    slope = (-A/B)
    quantity = (-2*A*B) if slope >= 0 else (A**2 + B**2)
    return (length**2 * quantity * fwhm**2)**(-1)
    

def get_lengths_from_gammas(gammas, A, B, fwhm_or_length):
    slope = (-A/B)
    
    quantity = (-2*A*B) if slope >= 0 else (A**2 + B**2)
    return (gammas*quantity*fwhm_or_length**2)**(-0.5)
    

                
                
def get_test_pars(values, npoints, gamma_lims, crits, other_par, opt_linear, A, B):
    
    """
    Determine the parameters to use for the optimization loop (be it pump FWHM
    or crystal length).
    
    Gamma is a dimensionless parameter that, when varied linearly, produces
    a log-like variation in the optimization parameter (be it crystal length L
    or pump FWHM sp). It is related to these parameters as:
    
    
        - .. math:: L^2 = 1 / (\gamma (-2AB) \sigma_p^2) \textrm{if} -A/B > 0
        
        - .. math:: L^2 = 1 / (\gamma (A^2 + B^2) \sigma_p^2) \textrm{if} -A/B < 0
    
    where A = \kappa'_p(\omega_p) - \kappa'_s(\omega_s), B = \kappa'_p(\omega_p) - \kappa'_i(\omega_i).
        
    
    Parameters
    ----------
    values : float, np.ndarray or iterable (unit: um for L, rad/s for FWHM)
        If float, taken as the central point of the set of values, which will
        be of size npoints in a logarithmic spread around this value.
        If np.ndarray, it will be immediately taken as the optimization values.
        If list, it has to be a list of size 2, corresponding to the minimum
        and maximum value to test.
        
    npoints : int
        Number of test points.
        
    gamma_lims : np.ndarray or iterable
        If np.ndarray, taken to be the gamma values for the search. Recall that
        gamma is a dimensionless parameter described above.
        If iterable, taken to be the minimum and maximum values of gamma to be
        considered in the search interval. Then the parameter is calculated
        using the above formula, with gamma being linearly distributed.
        
    crits : str
        When values is not given, or only a min and max value is given, the
        program automatically decides to test certain gammas, and use the con-
        version above to find the corresponding values of the parameter. In
        this case, it is a diferent selection of gammas according to the
        current optimization criterium, so it is here specified.
        
    other_par : float (unit: um for L, rad/s for FWHM)
        The value of the other parameter that is not being optimized, required
        for the conversion between the optimized parameter and the gammas.
    
    opt_linear : bool
        Whether to linearize the optimization parameter search array, after
        its limits are calculated.
    
    A, B : float (units: um^-1 / rad/s)
        Quantities involving the group velocity dispersions for pump, signal 
        and idler defined above.

    """
    
    if isinstance(values, np.ndarray):
        # a range with number of points is given, interprete
        
        # finish immediately, the values are given (either crystal lengths or
        # pump widths, need to calculate corresponding gamma)
        # don't care how many optimization points there are
        
        test_pars = values
        test_gammas = get_gammas_from_lengths(test_pars, A, B, other_par)
        
    elif isinstance(values, float):
        
        #if opt_base_val is given
        # do the optimization around the provided base value
        eq_gamma = get_gammas_from_lengths(values, A, B, other_par)

        # make sure that the base point comes in the test array
        if (npoints > 1) and (npoints%2 == 1.):
            npoints = npoints + 1
            test_gammas = np.linspace(0.1*eq_gamma, 10*eq_gamma, npoints)
        
        else:
            # number of points is 1, meaning a simulation with given length
            # and pump 
            test_gammas = np.array([eq_gamma])
        
        test_pars = get_lengths_from_gammas(test_gammas, A, B, other_par)
        
    elif (npoints > 1):

        # goes into the optimization loop even for one point
        
        if not gamma_lims:
            # do the optimization with the estimation for the base
            # value and with npoints
            
            # TODO: something here ?
            # gamma_lims = optimization.get('gammas', None)
                
            if ('pJSI' in crits) and len(crits) == 1:
                gamma_lims = (0.047, 0.049) if (-B/A >= 0.) else (0.02, 0.08)
                # we know the optimum gamma
                # gammas = np.linspace(0.03, 0.06, opt_npoints)

            else:
                gamma_lims = (0.010, 0.200)
            
            
            if isinstance(values, (tuple, list)):
                
                # squishy solution because the gammas and the parameters
                # are inversely related (larger gamma is smaller parameter)
                sugg_glims = [ gamma_lims[1-i] if values[i] == 'auto'  \
                               else get_gammas_from_lengths(values[i], A, B, other_par) \
                               for i in range(2) ]
                    
                sugg_glims.sort()
                
                gamma_lims = [ max([gamma_lims[0], sugg_glims[0]]), 
                               min([gamma_lims[1], sugg_glims[1]]) ]
                
            test_gammas = np.linspace(*gamma_lims, npoints)
            
        elif isinstance(gamma_lims, (tuple, list)):
            test_gammas = np.linspace(*gamma_lims, npoints)

        elif isinstance(gamma_lims, np.ndarray):
            test_gammas = gamma_lims
            
        test_pars = get_lengths_from_gammas(test_gammas, A, B, other_par)

    else:
        # case for opt_npoints = 0 or = 1
        # do not do optimization, only run with the values given
        test_pars = [0]; test_gammas = [0]
        
    if opt_linear:
        test_pars = np.linspace(np.min(test_pars),
                                np.max(test_pars),
                                npoints)
        
    
        
    return test_gammas, test_pars




def get_JSFs(pump, sigma_pump, signal, idler, material, 
             mode='angfreq', output='jsi', split_pm=False, npts=None, lims=None, 
             gamma=0.0478,
             force_same_wl_range=False, uniform_dx=False, resolution=None,
             verbose=False,
             filter_data={}):
    
    
    """
    Calculate Joint Spectral Functions (JSFs) around central frequencies. Uses 
    a custom window calculation algorithm based on user-defined margins from
    the PEF and the |PMF| central lines (see manual for more details). 

    Parameters
    ----------
    pump / signal / idler : floats    
        Pump / signal / idler wavelength (in um) or angular frequency (in 
        rad/s). All must be specified in the same unit of measurement.
    
    sigma_pump : float
        Pump standard deviation in amplitude. Note that this is not the usual
        pump FWHM in intensity. Same unit of measurement of pump.
    
    material : bishop.materials.Material
        The material to be used, contains as atributes the temperature, the con
        figurations and the relevant dispersion relations.
    
    mode : str (defaults to 'angfreq')
        The way in which the precedent variables are expressed (\'angfreq\' for
        angular frequency or \'wavelength\' for wavelength).
    
    split_pm : bool (defaults to False)
        Whether to split the phase matching function in amplitude and in phase.
        
    npts : int (defaults to None)
        Number of points to discretize the JSFs in signal and idler wavelengths.
        Can not be set simultaneously with resolution.
    
    resolution : float (defaults to None)
        The common resolution (in rad/s per point) that will be imposed on the
        signal and idler. Can not be set simultaneously with npts.
        
    lims : list (defaults to [])
        Limits for the spectral window of the JSFs. If provided, takes prece-
        dence over the automatic algorithm for the window calculation.
        It can be a list of two lists: [ [lim1_s, lim2_s], [lim1_i, lim2_i] ],
        where s and i refer to signal and idler (unit of measurement of pump)
        or a list of two floats [sigma_s, sigma_i], meaning how many pump ampli
        tude standard deviations to be used.
        If lims is set, the automatic window detection is NOT used.
    
    force_same_wl_range : bool (defaults to False)
        If set to True, will adjust the calculated or given limits in order to
        show the same wavelength range in signal and idler. It expands by a fac
        tor of two the shortest of these ranges (in angular frequency) and then
        contracts the longer range. 
    
    uniform_dx : bool (defaults to False)
        If True, makes so that the resolution (in rad/s per point) of signal
        and idler is the same.
    
    output : str (defaults to \'all\')
        \'jsi\': the output is the np.ndarray JSI (|PEF*PMF|^2).
                  
        \'all\': the output is signal angfreqs, idler angfreqs, PEF, PMF, PMF
        (Taylor). Both PMFs are lists [amplitude, phase] if split_pm was True, 
        or np.ndarrays amplitude*phase if split_pm was False.
        
        Adding '\+data\' to one of the above strings adds to the end of the re
        turned list the information poling_period, A, and B.
        
        \'verts\': Same output as \'all\', with a final list in the end contai
        ning the four bounding points (length 2 np.ndarrays) that the software
        determined based on the PMF_MARGIN and PEF_MARGIN (see manual for more).
        
        \'limits\': Returns only the calculated limits of the window, as a list
        of two tuples (lim1_s, lim2_s), (lim1_i, lim2_i), in rad/s.


    Output
    ------
    list
        The required joint spectral functions and additional information, in 
        accordance to the \'output\' keyword argument.
        
    """
    
    # check whether resolution and npts are given at the same time
    if resolution and npts:
        raise ValueError(('At least one of resolution and npts must be set to '
                          'None.'))

    [wp, spw, ws, wi], [wlp, spwl, wls, wli] = ps.parse_args(pump, sigma_pump, 
                                                             signal, idler,
                                                             input_mode=mode)

    # calculate the slope to get an idea of where will
    # be the point of maximum JSI, by intersecting
    # 1) wi = wp - ws
    # 2) wi = wi0 + slope*(ws-ws0)

    A, B = material.A_and_B(wlp, wls, wli)
    dk = material.dk(wlp, wls, wli)
    
    slope = -A/B

    pper = 2*us.PI/dk if material.pper is None else material.pper
    L = get_lengths_from_gammas(gamma, A, B, spw) if material.L is None else material.L
    
    if slope >= 0:
        # update angular frequencies to center the window
        wi0 = wi; ws0 = ws
        ws = (wp - wi0 + slope*ws0)/(1 + slope)
        wi = (wp - ws)
        [wls, wli] = bop.w2wl([ws, wi])
        
    plot_p = wp
    sigma_p_plot = spw
    plot_s = ws
    plot_i = wi

    if lims:
        
        if isinstance(lims[0], (tuple, list)):
            [plot_s_min, plot_s_max], _ = ps.parse_args(lims[0][0], lims[0][1], input_mode=mode)
            [plot_i_min, plot_i_max], _ = ps.parse_args(lims[1][0], lims[1][1], input_mode=mode)
            
            if plot_s_min > plot_s_max:
                tmp = plot_s_min
                plot_s_min = plot_s_max
                plot_s_max = tmp
    
            if plot_i_min > plot_i_max:
                tmp = plot_i_min
                plot_i_min = plot_i_max
                plot_i_max = tmp
                
            op1 = (plot_s_min, plot_i_min)
            op2 = (plot_s_min, plot_i_max)
            op3 = (plot_s_max, plot_i_min)
            op4 = (plot_s_max, plot_i_max)
        
        elif isinstance(lims[0], (int, float)):
            
            # use some standard deviations to delimit the window
            
            op1 = op2 = op3 = op4 = (ws, wi)
            
            plot_s_min = plot_s - lims[0]*sigma_p_plot 
            plot_s_max = plot_s + lims[0]*sigma_p_plot
            plot_i_min = plot_i - lims[1]*sigma_p_plot
            plot_i_max = plot_i + lims[1]*sigma_p_plot

        
    else:
        
        # in case of non totally overlapping PMF and PEF (where slope=-1), 
        # use adhoc limits to show as much as possible of the JSI

        # angle between the PEF and the PMF

        # np.arctan(np.abs(A/B)) is an angle in the 1st quad
        # so we make it into an angle of the second quadrant
        # amplitude between 90º and 180º
        angle_PMF = us.PI - np.arctan(np.abs(A/B))

        alpha = utils.smallest_angle_2_vecs(np.array([-1, 1]), np.array([-B, A]))

        perp_dist_to_PEF = np.sqrt(us.MARGIN_PEF)*spw
        # alpha_dist_to_PEF = perp_dist_to_PEF/np.sin(alpha) 

        # perp_dist_to_PMF = np.sqrt(n_plot_neg_slope**2/4/0.0478/L**2)/np.sqrt(A**2 + B**2)
        perp_dist_to_PMF = 2*us.MARGIN_PMF*us.PI/(L*np.sqrt(A**2 + B**2))
        # alpha_dist_to_PMF = perp_dist_to_PMF/np.sin(alpha)

        if slope > 1:
            delta = alpha
            alpha = us.PI - alpha

            beta = np.arctan(np.sin(alpha)/(perp_dist_to_PEF/perp_dist_to_PMF + np.cos(alpha)))
            epsilon = np.arctan(np.sin(delta)/(perp_dist_to_PMF/perp_dist_to_PEF + np.cos(delta))) 

            dist_to_corner = perp_dist_to_PMF/np.sin(beta)
            dist_to_corner_2 = perp_dist_to_PEF/np.sin(epsilon)

            angle_to_corner = 3*us.PI/4 + (alpha - beta)
            angle_to_corner_2 = 3*us.PI/4 - epsilon

        elif 1 > slope > 0:
            delta = us.PI - alpha

            beta = np.arctan(np.sin(alpha)/(perp_dist_to_PEF/perp_dist_to_PMF + np.cos(alpha)))
            epsilon = np.arctan(np.sin(delta)/(perp_dist_to_PMF/perp_dist_to_PEF + np.cos(delta))) 

            dist_to_corner = perp_dist_to_PMF/np.sin(beta)
            dist_to_corner_2 = perp_dist_to_PEF/np.sin(epsilon)

            angle_to_corner = 3*us.PI/4 + (alpha - beta)
            angle_to_corner_2 = 3*us.PI/4 - epsilon

        elif 0 > slope > -1:
            delta = us.PI - alpha

            beta = np.arctan(np.sin(alpha)/(perp_dist_to_PEF/perp_dist_to_PMF + np.cos(alpha)))
            epsilon = np.arctan(np.sin(delta)/(perp_dist_to_PMF/perp_dist_to_PEF + np.cos(delta))) 

            dist_to_corner = perp_dist_to_PMF/np.sin(beta)
            dist_to_corner_2 = perp_dist_to_PEF/np.sin(epsilon)

            angle_to_corner = 3*us.PI/4 + (alpha - beta)
            angle_to_corner_2 = 3*us.PI/4 - epsilon
            

        elif slope < -1:
            delta = us.PI - alpha

            beta = np.arctan(np.sin(alpha)/(perp_dist_to_PMF/perp_dist_to_PEF + np.cos(alpha)))
            epsilon = np.arctan(np.sin(delta)/(perp_dist_to_PEF/perp_dist_to_PMF + np.cos(delta)))

            dist_to_corner = perp_dist_to_PEF/np.sin(beta)
            dist_to_corner_2 = perp_dist_to_PMF/np.sin(epsilon)

            angle_to_corner = 3*us.PI/4 - beta
            angle_to_corner_2 = angle_PMF - epsilon

        unitary_to_corner = np.array([np.cos(angle_to_corner),
                                      np.sin(angle_to_corner)])

        unitary_to_corner_2 = np.array([np.cos(angle_to_corner_2),
                                        np.sin(angle_to_corner_2)])

        
        # unitary_1 = np.array([-B, A])/np.sqrt(A**2 + B**2)
        # unitary_2 = -unitary_1

        
        '''
        p1 = np.array([ws, wi]) \
             + wdw*alpha_dist_to_PEF/np.sqrt(2)*np.array([-1,1]) \
             + wdw*alpha_dist_to_PMF*unitary_1
        
        p2 = np.array([ws, wi]) \
             + wdw*alpha_dist_to_PEF/np.sqrt(2)*np.array([1,-1]) \
             + wdw*alpha_dist_to_PMF*unitary_2
        '''
        
        
        
        p_center = np.array([ws, wi])
        
        
        p1 = p_center + us.PLOT_WINDOW*dist_to_corner*unitary_to_corner
        p2 = p_center - us.PLOT_WINDOW*dist_to_corner*unitary_to_corner
        p3 = p_center + us.PLOT_WINDOW*dist_to_corner_2*unitary_to_corner_2
        p4 = p_center - us.PLOT_WINDOW*dist_to_corner_2*unitary_to_corner_2
        

        psmin = np.min([p1[0], p2[0], p3[0], p4[0]])
        pimax = np.max([p1[1], p2[1], p3[1], p4[1]])
        psmax = np.max([p1[0], p2[0], p3[0], p4[0]])
        pimin = np.min([p1[1], p2[1], p3[1], p4[1]])

        # in case he wants to go crazy to very high or low
        # wavelengths, we dont let him and do the 10 sigma rule
        
        if not us.OVERRIDE_LIMIT_CHANGE:
            plot_s_min = np.max([psmin, ws-10*sigma_p_plot])
            plot_i_max = np.min([pimax, wi+10*sigma_p_plot])
            plot_s_max = np.min([psmax, ws+10*sigma_p_plot])
            plot_i_min = np.max([pimin, wi-10*sigma_p_plot])
        else:
            plot_s_min = psmin
            plot_i_max = pimax
            plot_s_max = psmax
            plot_i_min = pimin
        
        
        if verbose:
            if plot_s_min != psmin:
                print("Limits updated to 10*sigma.")
            else:
                print("Limits taken as intersection points.")
        

        #  we can not let the pump go lower that the limits satisfy this 
        #  for signal and idler is not enough!
        #  maybe this is not that good after all... lets stick to changing 
        #  to some pump sigmas if things go south
        # plot_s_min = np.max( [ psmin, wl2w( material_wl_lims[material][1] ) ] )
        # plot_i_max = np.min( [ pimax, wl2w( material_wl_lims[material][0] ) ] )
        # plot_s_max = np.min( [ psmax, wl2w( material_wl_lims[material][0] ) ] )
        # plot_i_min = np.max( [ pimin, wl2w( material_wl_lims[material][1] ) ] )

        op1 = p_center + dist_to_corner*unitary_to_corner
        op2 = p_center - dist_to_corner*unitary_to_corner
        op3 = p_center + dist_to_corner_2*unitary_to_corner_2
        op4 = p_center - dist_to_corner_2*unitary_to_corner_2


    if force_same_wl_range:

        wl_s_lims = bop.w2wl([plot_s_min, plot_s_max])
        wl_i_lims = bop.w2wl([plot_i_min, plot_i_max])

        delta_wl_s = wl_s_lims[0] - wl_s_lims[1]
        delta_wl_i = wl_i_lims[0] - wl_i_lims[1]

        if delta_wl_s > delta_wl_i:
            # first expand a bit the shortest interval
            plot_i_min = plot_i - (plot_i - plot_i_min)*2
            plot_i_max = plot_i + (plot_i_max - plot_i)*2
        else:
            plot_s_min = plot_s - (plot_s - plot_s_min)*2
            plot_s_max = plot_s + (plot_s_max - plot_s)*2

        wl_s_lims = bop.w2wl([plot_s_min, plot_s_max])
        wl_i_lims = bop.w2wl([plot_i_min, plot_i_max])

        delta_wl_s = wl_s_lims[0] - wl_s_lims[1]
        delta_wl_i = wl_i_lims[0] - wl_i_lims[1]

        # comes in microns convert to meters
        delta_wl = np.min([delta_wl_i, delta_wl_s])*1e-6
        
        # we contract the longest range by finding the new limits for it in the
        # angular frequency domain. Suppose these new limits are w0+x and w0-x,
        # and the target wavelength interval is dwl. Then the equation to solve
        # is 2*us.PI*c*(1/(w0-x) - 1/(w0+x)) = dwl
        if delta_wl_s > delta_wl_i:
            _, x = utils.solve_quadratic(4*us.PI*us.C/delta_wl, -ws**2)
            plot_s_min, plot_s_max = plot_s - x, plot_s + x

        else:
            _, x = utils.solve_quadratic(4*us.PI*us.C/delta_wl, -wi**2)
            plot_i_min, plot_i_max = plot_i - x, plot_i + x

    
    if resolution:
        npts_s = int( (plot_s_max - plot_s_min) / resolution[0] )
        npts_i = int( (plot_i_max - plot_i_min) / resolution[1] )
        print(f'Using resolution constant, with {npts_s} x {npts_i}')
        
    elif uniform_dx:
        delta_s = plot_s_max - plot_s_min
        delta_i = plot_i_max - plot_i_min
        
        ds = delta_s / npts
        di = delta_i / npts
        
        if ds > di:
            # where spacing is the BIGGEST, I have to reduce it
            # in this case, make ds equal to di
            npts_s = int( delta_s / di )
            npts_i = npts
        
        else:
            npts_s = npts
            npts_i = int( delta_i / ds )
    else:
        npts_s = npts
        npts_i = npts
            
    
    plot_s_lin = np.linspace(plot_s_min, plot_s_max, npts_s)
    plot_i_lin = np.linspace(plot_i_min, plot_i_max, npts_i)
    plot_s_mg, plot_i_mg = np.meshgrid(plot_s_lin, plot_i_lin)


    pmf_out = phase_match_sq(plot_s_mg, plot_i_mg, material)
    pmf_app_out = phase_match_sq_approx(plot_s_mg, plot_i_mg, plot_s, plot_i, material)
    pef = pump_env_sq(plot_p, sigma_p_plot, plot_s_mg, plot_i_mg)
    
    
    if not split_pm:
        pmf_out = pmf_out[0]*pmf_out[1]
        pmf_app_out = pmf_app_out[0]*pmf_app_out[1]
        
    if output == 'jsi+data':
        return pmf_out[0]**2*pef**2, pper, A, B

    elif output == 'all+data':
        return [plot_s_mg, plot_i_mg, pef, pmf_out, pmf_app_out, pper, A, B]

    elif output == 'jsi':
        return pmf_out[0]**2*pef**2

    elif output == 'all':
        return [plot_s_mg, plot_i_mg, pef, pmf_out, pmf_app_out]

    elif output == 'verts':
        return [plot_s_mg, plot_i_mg, pef, pmf_out, pmf_app_out, [op1, op2, op3, op4]]
    
    elif output == 'limits':
        return [ (plot_s_min, plot_s_max), (plot_i_min, plot_i_max)]
        
