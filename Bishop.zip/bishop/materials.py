import dill
import numpy as np
from pathlib import Path

import bishop.settings as us
import bishop.parsing_functions as pf
import bishop.base_optics as bop

class Material():
    
    def __init__(self, name, dirs = None, refr_inds = None, kprimes = None, 
                 allowed_confs = None):
        
        self.name = name
        
        if refr_inds is not None:
            self.set_refr_index(dirs, refr_inds)
            self.set_kprime(dirs, kprimes)
        
        self.eff_confs = allowed_confs
        self.eff_confs_perm = pf.noperm2perm(allowed_confs)

        self.pper = None
        self.L = None
    
        
    def set_refr_index(self, directions, functions):
        self.refr_ind = {}
        for d, f in zip(directions, functions):    
            self.refr_ind[d] = f
    
    def set_conf(self, conf):
        self.conf = conf
        
    def set_kprime(self, directions, functions):
        self.kp = {}
        for d, f in zip(directions, functions):
            self.kp[d] = f
    
    def set_temperature(self, T):
        """Set the temperature of the crystal (unit: ºC)."""
        self.T = T
    
    def set_pper(self, pper):
        """Set the poling period of the crystal (unit: um)."""
        self.pper = pper
        
    def set_length(self, length):
        """Set the length of the crystal (unit: um)."""
        self.L = length
    
    def check_configurations(self, configs_list):
        """Check if the configuration is a possible crystal configuration.
        
        Possible configurations are provided in the initialization and are the
        ones for which the nonlinear coefficient is nonzero.
        """
        not_valids = ''.join([ c for c in configs_list if not (c in self.eff_confs) ])
            
        if not_valids:
            print(('The following configurations have nonlinear d = 0, so are '
                   'not physically possible: {not_valids}.'))
                   
    
    def dk(self, p, s, i, mode='wavelength', 
           conf: str | None = None, pper: float | None = None, temperature: float | None = None):
        r"""Calculate the mismatch at given spectral point.
        
        The mismatch is given by
        
        .. math ::
            
            \Delta \kappa = \kappa_p(\omega_p) -\kappa_s(\omega_s) - \kappa_i(\omega_i) - \kappa_\textrm{pol}
        
        Parameters
        ----------
        p, s, i : floats
            Pump, signal and idler wavelength (unit: um) or angular frequency
            (unit: rad/s).
        
        mode : str
            Options are 'wavelength' or 'angfreq' and indicate if p, s, and 
            are wavelengths or angular frequencies, respectively.
        
        conf : str
            Configuration (direction of polarization of pump, signal, and idler
            beams, condensed in a string `???`, where each `?` can be
            x, y or z). If no configuration is given, the one given when the 
            crystal was initialized will be used.
        
        pper : float
            Poling period of the crystal (unit: um). If no poling period is 
            given, the one given when the crystal was initialized will be used.
        
        temperature : float
            Temperature of the crystal (unit: um). If no temperature is given,
            the one given when the crystal was initialized will be used.
            
            
        Returns
        -------
        delta_k : float
            Phase mismatch (unit: um^-1).
        """
        [wp, ws, wi], [wlp, wls, wli] = pf.parse_args(p, s, i, input_mode=mode)
        
        conf = self.conf if conf is None else conf
        pconf, sconf, iconf = conf        
        T = temperature if temperature is not None else self.T
        pper = self.pper if pper is None else pper
        
        delta_k = self.k(pconf, wlp, T) - self.k(sconf, wls, T) - self.k(iconf, wli, T)
        
        if pper is not None:
            # pper is provided in the arguments
            delta_k -= 2*us.PI/pper
        
        return delta_k
        
    
    def A_and_B(self, p, s, i, mode='wavelength', 
                conf=None, pper=None, temperature=None):
        r"""Calculate the dispersion parameters A and B.
        
        The parameters are calculated by the formulas
        
        .. math ::
            
            A = \kappa'_p(\omega_p) - \kappa'_s(\omega_s)
            B = \kappa'_p(\omega_p) - \kappa'_i(\omega_i)
        
        
        Parameters
        ----------
        p, s, i : floats
            Pump, signal and idler wavelength (unit: um) or angular frequency
            (unit: rad/s).
        
        mode : str
            Options are 'wavelength' or 'angfreq' and indicate if p, s, and 
            are wavelengths or angular frequencies, respectively.
        
        conf : str
            Configuration (direction of polarization of pump, signal, and idler
            beams, condensed in a string `???`, where each `?` can be
            x, y or z). If no configuration is given, the one given when the 
            crystal was initialized will be used.
        
        pper : float
            Poling period of the crystal (unit: um). If no poling period is 
            given, the one given when the crystal was initialized will be used.
        
        temperature : float
            Temperature of the crystal (unit: um). If no temperature is given,
            the one given when the crystal was initialized will be used.
            
            
        Returns
        -------
        delta_k : float
            Phase mismatch (unit: um^-1).
        """
        [wp, ws, wi], [wlp, wls, wli] = pf.parse_args(p, s, i, input_mode=mode)
        
        conf = self.conf if conf is None else conf
        T = self.T if temperature is None else temperature
        pper = self.pper if pper is None else pper
        
        kw = {'temperature': T, 'pper': pper}
        
        
        if isinstance(conf, np.ndarray):
            # then we want to use a different refr_ind_str for every point in 
            # the signal and idler arrays
        
            A, B = np.zeros_like(s), np.zeros_like(i)
            nr, nc = np.shape(s)
        
            for i in range(nr):
                for j in range(nc):
                    pconf, sconf, iconf = conf[i, j]
                    A[i, j] = self.kprime(pconf, ws[i, j]+wi[i, j], **kw) -\
                              self.kprime(sconf, ws[i, j], **kw)
                    B[i, j] = self.kprime(pconf, ws[i, j]+wi[i, j], **kw) -\
                              self.kprime(iconf, ws[i, j], **kw)
                    
        else:
            pconf, sconf, iconf = conf
            A = self.kprime(pconf, ws+wi, **kw) - self.kprime(sconf, ws, **kw)
            B = self.kprime(pconf, ws+wi, **kw) - self.kprime(iconf, wi, **kw)
                    
        return A, B

        
    def k(self, ax, wl, temperature=None):
        T = self.T if temperature is None else temperature
        return self.refr_ind[ax](T)(wl) * 2*us.PI/wl
    
        
    def kprime(self, ax, omega, temperature=None, pper=None):
        
        method ='n'
        
        T = self.T if temperature is None else temperature
        pper = self.pper if pper is None else pper
        
        wl = bop.w2wl(omega)
        
        if method == 'n':
            # Unit: um^-1 / um = um^-2
            dk_dwl = (self.k(ax, wl+us.K_PRIME_PRECISION, T)-\
                      self.k(ax, wl-us.K_PRIME_PRECISION, T))\
                      /2/us.K_PRIME_PRECISION
        
        
            # print(dk_dwl, self.kp[ax](T)(wl))
            
        else:
            dk_dwl = self.kp[ax](T)(wl)
            
        dwl_dw = -2*us.PI*us.C/omega**2*1e6  # Unit: um / (rad/s)
        dk_dw = dk_dwl*dwl_dw                # Unit: um^-1 / rad/s)
        
        return dk_dw
            
    
    def save(self):
        with open(Path.cwd()/'pickles'/f'{self.name}.pkl', 'wb') as p:    
            dill.dump(self, p)


        

  


# THESE ARE NOT ALL ELIGIBLE CONFIGURATIONS but every 2 configurations where
# signal is exchanged with idler appear only once,
# eg nx_nz_nx does not appear if nx_nx_nz has already appeared, WATCH OUT!
mat_confs_noperm = {'ppLT': ['nx_nx_nx', 'nz_nz_nz', 'ny_nz_ny', 'nz_ny_ny'],
                    'KDP': ['nx_nz_nx', 'nz_nx_nx'] }


mat_confs_perm = {'ppLT': ['nx_nx_nx', 'nz_nz_nz', 'ny_nz_ny', 'ny_ny_nz',
                           'nz_ny_ny'],
                  'KDP':  ['nx_nz_nx', 'nx_nx_nz', 'nz_nx_nx']}


chi2_ppLN = {}

chi2_KTP = {'15': 1.9e-12, '24': 4.2e-12, '31': 2.2e-12,
            '32': 2.7e-12, '33': 17.4e-12}

chi2_dict = { 'ppLN': chi2_ppLN,
              'ppKTP': chi2_KTP,
              'wgKTP': chi2_KTP }

material_wl_lims = { 'ppLN': [0.3, 5],
                     'ppKTP': [0.3, 5],
                     'ppLT': [0.3, 5] }

directions_numbers_dict = {'x': 1, 'y': 2, 'z': 3}


def contract_notation(string):

    contract_dict = {'xx': 1, 'yy': 2, 'zz': 3,
                     'yz': 4, 'zy': 4,
                     'xz': 5, 'zx': 5,
                     'xy': 6, 'yx': 6}

    return str(contract_dict[string])


def chi2(material, configuration):

    contr_not = str(directions_numbers_dict[configuration[0]])
    contr_not += contract_notation(configuration[1:])

    chi2 = chi2_dict[material]

    return chi2[contr_not]






# kpump = lambda wl: npump(wl)*2*pi/wl  # units of this are um^-1! no, a c is not missing...
# ks = lambda wl: ns(wl)*2*pi/wl        # units of this are um^-1!
# ki = lambda wl: ni(wl)*2*pi/wl        # units of this are um^-1!

# kpump_w = lambda w: npump(2*pi*c/w*1e6)*w/c 
# ks_w = lambda w: ns(2*pi*c/w*1e6)*w/c
# ki_w = lambda w: ni(2*pi*c/w*1e6)*w/c

is2cd = lambda i1,i2,i3: 100*i1 + 10*i2 + i3
cd2is = lambda code: [int(code//100), int((code%100)//10), int((code%100)%10)]




###############################################################################
########################## LT material properties #############################
###############################################################################


F2 = lambda T: (T-24.5)*(T + 568)



def refr_ind_x_ppLT(T):

    def nx_function(wl):
        return np.sqrt( 4.46828481 + 2.55011881e-8*F2(T) - 0.01791123*wl**2 + \
                        (0.10437434 + 2.30759571e-8*F2(T))/(wl**2 - (1.84334432e-11*F2(T))**2) \
                         - 2.84541849e-3/wl**4 + 7.87317793e-4/wl**6 )

    return nx_function



def refr_ind_y_ppLT(T):

    def ny_function(wl):
        return np.sqrt( 4.46828481 + 2.55011881e-8*F2(T) - 0.01791123*wl**2 + \
                        (0.10437434 + 2.30759571e-8*F2(T))/(wl**2 - (1.84334432e-11*F2(T))**2) \
                         - 2.84541849e-3/wl**4 + 7.87317793e-4/wl**6 )

    return ny_function



def refr_ind_z_ppLT(T):

    def nz_function(wl):
        return np.sqrt( 4.49361274 + 2.49194536e-7*F2(T) - 0.02299905*wl**2 + \
                        (0.09659086 + 4.34187245e-8*F2(T))/(wl**2 - (7.43750502e-11*F2(T))**2) \
                         - 1.0505035e-3/wl**4 + 6.30479079e-4/wl**6 )
    return nz_function



n_dict_ppLT = { 'x': refr_ind_x_ppLT,
                'y': refr_ind_y_ppLT,
                'z': refr_ind_z_ppLT }




###############################################################################
########################## KDP material properties ############################
###############################################################################

def refr_ind_x_KDP(T):

    def nx_function(wl):
        return np.sqrt( 2.25881 + 11.86370*wl**2/(wl**2 - 400.) + \
                        0.01041/(wl**2 - 0.01209) )

    return nx_function


def refr_ind_y_KDP(T):

    def ny_function(wl):
        return np.sqrt( 2.25881 + 11.86370*wl**2/(wl**2 - 400.) + \
                        0.01041/(wl**2 - 0.01209) )

    return ny_function


def refr_ind_z_KDP(T):

    def nz_function(wl):
        return np.sqrt( 2.13338 + 2.93795*wl**2/(wl**2 - 400.) + \
                        0.00873/(wl**2 - 0.01203) )

    return nz_function


n_dict_KDP = { 'x': refr_ind_x_KDP,
               'y': refr_ind_y_KDP,
               'z': refr_ind_z_KDP }


str_av_mats = 'ppLN, ppKTP, ppLT and KDP'
