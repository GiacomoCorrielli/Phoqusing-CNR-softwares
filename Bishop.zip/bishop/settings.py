###############################################################################
########################### PHYSICAL CONSTANTS ################################            
###############################################################################

PI = 3.1415926                   # Pi
H = 6.62607004e-34               # Planck constant [J.s] 
HBAR = H/(2*PI)                  # Normalized Planck constant [J.s]
EPS0 = 8.8541878128e-12          # Vaccuum permittivity [F/m]
C = 2.99792458e8                 # Speed of light [m/s]


###############################################################################
############################ PLOTTING OPTIONS #################################
###############################################################################

# Whether to use latex in all graphs
USE_LATEX = False

if USE_LATEX:
    AXIS_TITLES = {'wavelength': (r'$\lambda_1$ [\si{\um}]', 
                                        r'$\lambda_2$ [\si{\um}]'),
                    'angfreq': (r'$\omega_1$ [\si{\radian\per\second}]', 
                                r'$\omega_2$ [\si{\radian\per\second}]'),
                    'true wavelength': (r'$\lambda_1$ [\si{\um}]', 
                                        r'$\lambda_2$ [\si{\um}]')}

else:
    AXIS_TITLES = {'wavelength': [ r'λ_1 [μm]', r'λ_2 [μm]' ],
                    'angfreq': [ r'ω_1 [rad/s]', r'ω_2 [rad/s]' ],
                    'true wavelength': [ r'$λ_1$ [μm]', r'$λ_2$ [μm]' ]}


if USE_LATEX:
    
    suptitle_PEF = r'$\textrm{PEF}$'
    suptitle_PEFsq = r'$\textrm{PEF}^2$'
    
    suptitle_PMFabs = r'$|\textrm{PMF}|$'
    suptitle_PMFabs_app = r'$|\textrm{PMF}_\textrm{app}|$'
    suptitle_PMFsq = r'$|\textrm{PMF}|^2$'
    suptitle_PMFsq_app = r'$\textrm{PMF}_\textrm{app}^2$'
    
    suptitle_JSA_noph = r'$\textrm{PEF} \cdot \textrm{sinc} (\Delta k L/2)$'
    suptitle_JSA_app_noph = r'$\textrm{PEF} \cdot \textrm{sinc} (\Delta k_{approx} L/2)$'
    suptitle_JSAabs = r'$|\textrm{JSA}|$'
    suptitle_JSAabs_app = r'$|\textrm{JSA}_\textrm{app}|$'
    suptitle_JSI = r'$\textrm{JSI}$'
    suptitle_JSI_app = r'$\textrm{JSI}_\textrm{app}$'
    
    
    GRAPH_TITLES_DICT = {'slope': r'$\textrm{slope} = -A/B$',
                         'poling_period': r'$\Lambda [\si{\um}]$',
                         'pJSA': r'\textrm{JSA purity}',
                         'pJSI': r'\textrm{JSI purity}',
                         'pJSAnp': r'\textrm{JSAnp purity}',
                         'gJSA': r'$\gamma_{\textrm{opt}}$',
                         'gJSI': r'$\gamma_{\textrm{opt}}$',
                         'adim_opt_par': r'$L [\si{\mm}] / (\lambda^2_p [\si{\um^2}] / \sigma_p [\si{\nm}])$',
                         'JSI_asym': r'$\sigma^{\textrm{(JSI)}}_x / \sigma^{\textrm{(JSI)}}_y$',
                         'visibility': r'$p_\textrm{JSA} - ||\rho_s - \rho_i||^2 / 2$',
                         'operational_distance': r'$||\rho_s - \rho_i||^2$',
                         'crystal_length': 'L',
                         'pump_FWHM': r'FWHM_p' }

else:
    
    suptitle_PEF = 'PEF'
    suptitle_PEFsq = r'$PEF^2$'
    
    suptitle_PMFabs = r'$|PMF|$'
    suptitle_PMFabs_app = r'$|PMF_{approx}|$'
    suptitle_PMFsq = r'${|PMF|}^2$'
    suptitle_PMFsq_app = r'${|PMF_{approx}|}^2$'
    
    suptitle_JSA_noph = r'$PEF x sinc( \Delta k L/2 )$'
    suptitle_JSA_app_noph = r'$PEF x sinc( \Delta k_{approx} L/2 )$'
    suptitle_JSAabs = r'$|JSA|$'
    suptitle_JSAabs_app = r'$|JSA_{approx}|$'
    suptitle_JSI = 'JSI'
    suptitle_JSI_app = r'$JSI_{approx}$'
    
    GRAPH_TITLES_DICT = {'slope': '-A/B',
                         'poling_period': r'Λ [μm]$',
                         'pJSA': '{JSA} purity',
                         'pJSI': '{JSI} purity',
                         'pJSAnp': '{JSAnp} purity',
                         'gJSA': r'γ^{JSA}',
                         'gJSI': r'γ^{JSI}',
                         'adim_opt_par': r'L [mm] / (λ^2_p [μm^2}] / σ_p [nm])',
                         'JSI_asym': r'σ^{JSI}_x / σ^{JSI}_y',
                         'visibility': r'p_{JSA} - ||ρ_s - ρ_i||^2 / 2',
                         'operational_distance': r'||ρ_s - ρ_i||^2',
                         'crystal_length': 'L',
                         'pump_FWHM': r'FWHM_p' }
    

tit_dict = { 'PEF': suptitle_PEF,
             'PEFSq': suptitle_PEFsq,
             'PMF': suptitle_PMFabs,
             'PMFApp': suptitle_PMFabs_app,
             'PMFSq': suptitle_PMFsq,
             'PMFAppSq': suptitle_PMFsq_app,
             'JSA': suptitle_JSAabs,
             'JSAApp': suptitle_JSAabs_app,
             'JSAnp': suptitle_JSA_noph,
             'JSAAppNp': suptitle_JSA_app_noph,
             'JSI': suptitle_JSI,
             'JSIApp': suptitle_JSI_app }


# type of colorbar for the joint spectral functions
# one: one colorbar in the rightmost plot
# all: one colorbar to the right of each subplot
JOINT_SPECTRAL_PLOTS_CB_TYPE = 'one'

JOINT_SPECTRAL_PLOTS_AXIS = 'wavelength'

# aspect ratio for the Joint Spectral Plots, can be either
# equal:   force an equal aspect ratio, meaning that the same physical distance 
#          in both scales is going to represent different data intervals
# unequal: force an unequal aspect ratio, meaning that the graph will truly
#          represent, for equal physical distances, equal data intervals
# auto (default): decide automatically based on the values in both axis
JOINT_SPECTRAL_PLOTS_AR = 'unequal'

# dots per inch for the Joint Spectral Plots
JOINT_SPECTRAL_PLOTS_DPI = 300

# points in each axis of the JSFs arrays for plotting Joint Spectral Plots
JOINT_SPECTRAL_PLOTS_POINTS = 300

# points in each axis of the JSFs arrays for plotting Sweep Plots
SWEEP_PLOTS_DPI = 300

# whether to show or not the intersection lines between the PEF and the PMF
SHOW_LINES_JSF_PLOT = True

# number of curves of equal pump wavelenght to be drawn on the sweep plots (the
# starting and ending wavelengths are either automatic or decided in the
# sweep plots function)
NUMBER_OF_ISOPUMP_CURVES = 10

# dots per inch to save all graphics
PLOTS_SAVE_DPI = 400




###############################################################################
############################### PATH OPTIONS ##################################
###############################################################################

PATH_TO_SIMULATIONS = '/home/hjdno/Documents/PhD/simulations'






###############################################################################
############################# MAIN LOOP OPTIONS ###############################
###############################################################################


# This gamma is for the gaussian approximation, it guarantees that the integral
# square difference between the exp(-gamma * x^2) and sinc(x/2)^2 is minimum
GA_GAMMA = 0.0953

# number of points to use in the purity calculations
PURITY_CALC_POINTS = 1000

# whether to continue the optimization loop if the slope of the PMF has a nega
# tive sign (meaning it overlaps with the PEF). It is advised to keep it True.
OVERRIDE_SLOPE_CRITERIUM = True

# number of points for the main loop of the best_configuration file
OPT_LOOP_NPOINTS = 300

# if None, means that the OPT_LOOP_NPOINTS will be used for the discretization
# of the joint spectral functions in the best_configuration main loop
# if set to a number, means the resolution to be imposed for the discretization
# (in rad/s per point)
OPT_LOOP_RESOLUTION = None



K_PRIME_PRECISION = 1e-5


###############################################################################
######################## WINDOW ALGORITHM OPTIONS #############################
###############################################################################

# pump envelope function margin for calculation of the purity spectral window
# (means after how many intensity standard deviations from the pump we are 
# willing to lose information when calculating the purity)
MARGIN_PEF = 3

# phase matching function margin for calculation of the purity spectral window
# (means after how many zeroes of the sinc^2 function we are willing to lose 
# information when calculating the purity)
MARGIN_PMF = 15

# number of magnification of the central part of the JSI / JSA that will be
# used for computing the purity
# for best results, DO NOT TOUCH this variable and change instead the margins 
# of the PEF and the PMF
PLOT_WINDOW = 1

# by default, the limits of the JSFs are updated to 10 sigma if the calculated
# limits exceed 10 sigma pump, if this is not intended change this flag to True
# to override this behaviour
OVERRIDE_LIMIT_CHANGE = False



###############################################################################
################## GENERATION RATE CALCULATION OPTIONS ########################
###############################################################################

INT_KAPPA_TAYLOR = 0
INT_KAPPA_MODE = 0

# Number of standard deviations between which to integrate the joint spectral
# functions for the generation rate calculation
INT_KAPPA_LIM = 12

# parameter for integral subdivisions
INT_KAPPA_OPTS = {'limit': 200}         

TARGET_BETA_SQ = 0.01

# global time bandwidth product
#GLOBAL_TBP = 1.0
GLOBAL_TBP = 0.4413



###############################################################################
################################# MATERIALS ###################################
###############################################################################

import dill
from pathlib import Path

p = Path(__file__).parent /'data'/'materials'/'pickles'
MATERIALS = {}

for path in p.iterdir():
    with open(path, 'rb') as p:
        mt = dill.load(p)
        MATERIALS[path.stem] = mt
